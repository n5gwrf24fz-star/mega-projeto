const express = require('express');
const EducationController = require('../controllers/educationController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/grade-levels', EducationController.listGradeLevels);
router.get('/grade-levels/:id/subjects', EducationController.listSubjects);
router.get('/subjects/:id/lessons', EducationController.listLessons);
router.get('/subjects/:id/progress', requireAuth, EducationController.subjectProgress);

router.get('/lessons/:id', requireAuth, EducationController.getLesson);
router.post('/lessons/:id/complete', requireAuth, EducationController.completeLesson);

router.post('/exercises/:id/answer', requireAuth, EducationController.answerExercise);

router.get('/mock-exams/:id', requireAuth, EducationController.getMockExam);

module.exports = router;
