const express = require('express');
const LanguageController = require('../controllers/languageController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', LanguageController.listLanguages);
router.get('/certificates', requireAuth, LanguageController.myCertificates);
router.get('/:id/units', LanguageController.listUnits);
router.get('/:id/progress', requireAuth, LanguageController.myProgress);

router.get('/units/:id', requireAuth, LanguageController.getUnit);
router.post('/units/:id/complete', requireAuth, LanguageController.completeUnit);

router.get('/flashcard-decks/:deckId/review', requireAuth, LanguageController.flashcardsDue);
router.post('/flashcards/:id/review', requireAuth, LanguageController.reviewFlashcard);

module.exports = router;
