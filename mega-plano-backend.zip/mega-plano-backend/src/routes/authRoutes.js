const express = require('express');
const rateLimit = require('express-rate-limit');
const AuthController = require('../controllers/authController');
const SocialAuthController = require('../controllers/socialAuthController');
const TwoFactorController = require('../controllers/twoFactorController');
const { requireAuth } = require('../middleware/auth');
const { registerRules, loginRules } = require('../middleware/validators');

const router = express.Router();

// Limita tentativas de login/registro para dificultar força bruta e criação em massa de contas.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Muitas tentativas. Tente novamente em alguns minutos.' },
});

// Limite mais apertado para tentativas de código (2FA, verificação, reset).
const codeLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 6,
  message: { error: 'Muitas tentativas. Tente novamente em alguns minutos.' },
});

// --- E-mail/senha ---
router.post('/register', authLimiter, registerRules, AuthController.register);
router.post('/login', authLimiter, loginRules, AuthController.login);
router.post('/refresh', AuthController.refresh);
router.post('/logout', AuthController.logout);
router.get('/me', requireAuth, AuthController.me);
router.patch('/me', requireAuth, AuthController.updateMe);

// --- Verificação de e-mail ---
router.get('/verify-email', AuthController.verifyEmail);
router.post('/resend-verification', authLimiter, AuthController.resendVerification);

// --- Redefinição de senha ---
router.post('/forgot-password', authLimiter, AuthController.forgotPassword);
router.post('/reset-password', codeLimiter, AuthController.resetPassword);

// --- Login social ---
router.post('/google', authLimiter, SocialAuthController.google);
router.post('/apple', authLimiter, SocialAuthController.apple);

// --- Autenticação em duas etapas (TOTP) ---
router.post('/2fa/setup', requireAuth, TwoFactorController.setup);
router.post('/2fa/enable', requireAuth, codeLimiter, TwoFactorController.enable);
router.post('/2fa/disable', requireAuth, codeLimiter, TwoFactorController.disable);
router.post('/2fa/login-verify', codeLimiter, TwoFactorController.verifyLogin);

module.exports = router;
