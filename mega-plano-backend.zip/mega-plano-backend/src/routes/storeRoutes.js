const express = require('express');
const StoreController = require('../controllers/storeController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/products', StoreController.listProducts);
router.get('/my-purchases', requireAuth, StoreController.myPurchases);
router.post('/purchase/:productId', requireAuth, StoreController.purchaseWithCoins);

module.exports = router;
