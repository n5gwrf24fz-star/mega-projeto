const express = require('express');
const GamificationController = require('../controllers/gamificationController');
const { FavoriteController } = require('../controllers/favoriteController');
const { NotificationController } = require('../controllers/notificationController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Tudo neste arquivo é pessoal do usuário — exige autenticação.
router.use(requireAuth);

router.get('/status', GamificationController.myStatus);
router.get('/achievements', GamificationController.listAchievements);

router.get('/favorites', FavoriteController.list);
router.post('/favorites', FavoriteController.add);
router.delete('/favorites', FavoriteController.remove);

router.get('/notifications', NotificationController.list);
router.get('/notifications/unread-count', NotificationController.unreadCount);
router.patch('/notifications/:id/read', NotificationController.markRead);
router.patch('/notifications/read-all', NotificationController.markAllRead);

module.exports = router;
