const express = require('express');
const AdminContentController = require('../controllers/adminContentController');
const AdminAnnouncementController = require('../controllers/adminAnnouncementController');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth, requireRole('admin', 'super_admin'));

// --- Educação ---
router.post('/grade-levels', AdminContentController.createGradeLevel);
router.patch('/grade-levels/:id', AdminContentController.updateGradeLevel);
router.delete('/grade-levels/:id', AdminContentController.deleteGradeLevel);

router.post('/subjects', AdminContentController.createSubject);
router.patch('/subjects/:id', AdminContentController.updateSubject);
router.delete('/subjects/:id', AdminContentController.deleteSubject);

router.post('/lessons', AdminContentController.createLesson);
router.patch('/lessons/:id', AdminContentController.updateLesson);
router.delete('/lessons/:id', AdminContentController.deleteLesson);

router.post('/exercises', AdminContentController.createExercise);
router.patch('/exercises/:id', AdminContentController.updateExercise);
router.delete('/exercises/:id', AdminContentController.deleteExercise);

// --- Idiomas ---
router.post('/languages', AdminContentController.createLanguage);
router.post('/language-units', AdminContentController.createLanguageUnit);
router.patch('/language-units/:id', AdminContentController.updateLanguageUnit);
router.delete('/language-units/:id', AdminContentController.deleteLanguageUnit);
router.post('/vocabulary', AdminContentController.createVocabularyItem);
router.delete('/vocabulary/:id', AdminContentController.deleteVocabularyItem);

// --- Games (Gaming Settings) ---
router.post('/games', AdminContentController.createGame);
router.patch('/games/:id/active', AdminContentController.toggleGame);
router.post('/game-guides', AdminContentController.createGameGuide);
router.patch('/game-guides/:id', AdminContentController.updateGameGuide);
router.delete('/game-guides/:id', AdminContentController.deleteGameGuide);

// --- Anúncios (push/broadcast) ---
router.post('/announcements', AdminAnnouncementController.broadcast);

module.exports = router;
