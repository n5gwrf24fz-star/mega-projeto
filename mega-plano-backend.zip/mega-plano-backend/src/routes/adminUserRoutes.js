const express = require('express');
const AdminUserController = require('../controllers/adminUserController');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth, requireRole('admin', 'super_admin'));

router.get('/users', AdminUserController.search);
router.get('/users/:id', AdminUserController.getById);
router.post('/users/:id/ban', AdminUserController.ban);
router.post('/users/:id/unban', AdminUserController.unban);
// Trocar a role de alguém é mais sensível que banir — restrito a super_admin.
router.post('/users/:id/role', requireRole('super_admin'), AdminUserController.changeRole);

router.get('/audit-logs', AdminUserController.listAuditLogs);

module.exports = router;
