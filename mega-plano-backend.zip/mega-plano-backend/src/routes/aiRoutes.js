const express = require('express');
const AiController = require('../controllers/aiController');
const { requireAuth } = require('../middleware/auth');
const aiUsageLimit = require('../middleware/aiUsageLimit');

const router = express.Router();

router.use(requireAuth);

router.get('/conversations', AiController.listConversations);
router.get('/conversations/:id', AiController.getConversation);
router.delete('/conversations/:id', AiController.deleteConversation);
// aiUsageLimit fica só na rota que efetivamente chama o modelo (é ela que custa dinheiro).
router.post('/conversations/:id/messages', aiUsageLimit, AiController.sendMessage);

module.exports = router;
