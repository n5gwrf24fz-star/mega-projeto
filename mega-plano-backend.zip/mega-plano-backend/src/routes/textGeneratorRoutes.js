const express = require('express');
const { TextGeneratorController } = require('../controllers/textGeneratorController');
const { requireAuth } = require('../middleware/auth');
const aiUsageLimit = require('../middleware/aiUsageLimit');

const router = express.Router();

router.use(requireAuth);

router.get('/history', TextGeneratorController.history);
router.post('/generate', aiUsageLimit, TextGeneratorController.generate);

module.exports = router;
