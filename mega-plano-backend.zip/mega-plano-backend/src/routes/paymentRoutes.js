const express = require('express');
const SubscriptionController = require('../controllers/subscriptionController');
const WebhookController = require('../controllers/webhookController');
const CoinsController = require('../controllers/coinsController');
const CouponController = require('../controllers/couponController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// --- Planos e assinaturas (autenticado) ---
router.get('/plans', SubscriptionController.listPlans);
router.get('/me', requireAuth, SubscriptionController.myStatus);
router.post('/checkout/stripe', requireAuth, SubscriptionController.createStripeCheckout);
router.post('/cancel', requireAuth, SubscriptionController.cancel);
router.post('/verify/apple', requireAuth, SubscriptionController.verifyApple);
router.post('/verify/google', requireAuth, SubscriptionController.verifyGoogle);

// --- Mega Coins ---
router.get('/coins/balance', requireAuth, CoinsController.balance);
router.get('/coins/history', requireAuth, CoinsController.history);
router.post('/coins/buy-pix', requireAuth, CoinsController.buyWithPix);

// --- Cupons ---
router.post('/coupons/redeem', requireAuth, CouponController.redeem);

// --- Webhooks (chamados pelos provedores, nunca pelo app — sem requireAuth) ---
// OBS: o webhook do Stripe é montado separadamente em app.js, ANTES do
// express.json() global, pois precisa do corpo cru para validar a assinatura.
router.post('/webhooks/apple', express.json(), WebhookController.apple);
router.post('/webhooks/google', express.json(), WebhookController.google);
router.post('/webhooks/mercado-pago', express.json(), WebhookController.mercadoPago);

module.exports = router;
