const express = require('express');
const { NoteController } = require('../controllers/noteController');
const { ChecklistController } = require('../controllers/checklistController');
const ToolsController = require('../controllers/toolsController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// --- Utilitários sem estado (não exigem login) ---
router.get('/password', ToolsController.generatePassword);
router.post('/qrcode', ToolsController.generateQrCode);
router.get('/currency/convert', ToolsController.convertCurrency);

// --- Notas (autenticado) ---
router.get('/notes', requireAuth, NoteController.list);
router.post('/notes', requireAuth, NoteController.create);
router.patch('/notes/:id', requireAuth, NoteController.update);
router.delete('/notes/:id', requireAuth, NoteController.remove);

// --- Checklists (autenticado) ---
router.get('/checklists', requireAuth, ChecklistController.list);
router.post('/checklists', requireAuth, ChecklistController.create);
router.delete('/checklists/:id', requireAuth, ChecklistController.remove);
router.post('/checklists/:id/items', requireAuth, ChecklistController.addItem);
router.patch('/checklists/:id/items/:itemId/toggle', requireAuth, ChecklistController.toggleItem);
router.delete('/checklists/:id/items/:itemId', requireAuth, ChecklistController.removeItem);

module.exports = router;
