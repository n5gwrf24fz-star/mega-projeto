const express = require('express');
const { GameController } = require('../controllers/gameController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', GameController.listGames);
router.get('/:slug/guides', GameController.listGuides);
router.post('/:slug/sensitivity', requireAuth, GameController.saveSensitivity);
router.get('/:slug/sensitivity', requireAuth, GameController.listSensitivityConfigs);

module.exports = router;
