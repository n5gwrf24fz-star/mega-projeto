const express = require('express');
const AdminFinanceController = require('../controllers/adminFinanceController');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// Todo o painel financeiro exige admin ou super_admin autenticado.
router.use(requireAuth, requireRole('admin', 'super_admin'));

router.get('/subscriptions', AdminFinanceController.listSubscriptions);
router.get('/revenue', AdminFinanceController.revenue);
router.get('/summary', AdminFinanceController.summary);

router.get('/coupons', AdminFinanceController.listCoupons);
router.post('/coupons', AdminFinanceController.createCoupon);
router.delete('/coupons/:id', AdminFinanceController.deactivateCoupon);

router.post('/store/products', AdminFinanceController.createStoreProduct);
router.get('/store/products', AdminFinanceController.listStoreProducts);
router.patch('/store/products/:id/active', AdminFinanceController.toggleStoreProduct);

// Conceder Mega Coins é ação sensível — restrita a super_admin.
router.post('/coins/grant', requireRole('super_admin'), AdminFinanceController.grantCoins);

module.exports = router;
