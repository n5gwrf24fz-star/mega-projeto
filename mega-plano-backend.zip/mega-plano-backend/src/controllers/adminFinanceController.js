const SubscriptionModel = require('../models/subscriptionModel');
const PaymentModel = require('../models/paymentModel');
const CouponModel = require('../models/couponModel');
const StoreModel = require('../models/storeModel');
const CoinsModel = require('../models/coinsModel');
const AuditLogModel = require('../models/auditLogModel');
const { query } = require('../config/db');

function parseRange(req) {
  const to = req.query.to ? new Date(req.query.to) : new Date();
  const from = req.query.from ? new Date(req.query.from) : new Date(to.getTime() - 30 * 24 * 60 * 60 * 1000);
  return { from, to };
}

const AdminFinanceController = {
  // GET /api/admin/finance/subscriptions?status=active&plan=pro
  async listSubscriptions(req, res, next) {
    try {
      const { status, plan } = req.query;
      const limit = Number(req.query.limit) || 50;
      const offset = Number(req.query.offset) || 0;
      const subscriptions = await SubscriptionModel.listForAdmin({ status, plan, limit, offset });
      return res.json({ subscriptions });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/admin/finance/revenue?from=...&to=...
  async revenue(req, res, next) {
    try {
      const { from, to } = parseRange(req);
      const summary = await PaymentModel.revenueSummary({ from, to });
      const byPlan = await PaymentModel.revenueByPlan({ from, to });
      return res.json({
        period: { from, to },
        totalRevenueCents: Number(summary.total_cents),
        successfulPayments: Number(summary.successful_count),
        failedPayments: Number(summary.failed_count),
        refundedPayments: Number(summary.refunded_count),
        byPlan,
      });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/admin/finance/summary — visão geral pro dashboard do admin
  async summary(req, res, next) {
    try {
      const { rows: planCounts } = await query(
        `SELECT plan, COUNT(*) AS user_count FROM users GROUP BY plan`
      );
      const { rows: activeSubs } = await query(
        `SELECT plan, COUNT(*) AS count FROM subscriptions WHERE status IN ('active','trialing') GROUP BY plan`
      );

      return res.json({
        usersByPlan: planCounts,
        activeSubscriptionsByPlan: activeSubs,
      });
    } catch (err) {
      next(err);
    }
  },

  // --- Cupons ---
  // GET /api/admin/finance/coupons
  async listCoupons(req, res, next) {
    try {
      const coupons = await CouponModel.listAll();
      return res.json({ coupons });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/admin/finance/coupons  { code, type, value, maxRedemptions?, expiresAt? }
  async createCoupon(req, res, next) {
    try {
      const { code, type, value, maxRedemptions, expiresAt } = req.body;
      const coupon = await CouponModel.create({ code, type, value, maxRedemptions, expiresAt, createdBy: req.user.sub });
      return res.status(201).json({ coupon });
    } catch (err) {
      next(err);
    }
  },

  // DELETE /api/admin/finance/coupons/:id
  async deactivateCoupon(req, res, next) {
    try {
      await CouponModel.deactivate(req.params.id);
      return res.json({ message: 'Cupom desativado.' });
    } catch (err) {
      next(err);
    }
  },

  // --- Loja ---
  // GET /api/admin/finance/store/products
  async listStoreProducts(req, res, next) {
    try {
      const products = await StoreModel.listAllForAdmin();
      return res.json({ products });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/admin/finance/store/products
  async createStoreProduct(req, res, next) {
    try {
      const product = await StoreModel.create(req.body);
      return res.status(201).json({ product });
    } catch (err) {
      next(err);
    }
  },

  // PATCH /api/admin/finance/store/products/:id/active  { active }
  async toggleStoreProduct(req, res, next) {
    try {
      await StoreModel.setActive(req.params.id, req.body.active);
      return res.json({ message: 'Produto atualizado.' });
    } catch (err) {
      next(err);
    }
  },

  // --- Mega Coins ---
  // POST /api/admin/finance/coins/grant  { userId, amount, note }
  async grantCoins(req, res, next) {
    try {
      const { userId, amount } = req.body;
      const result = await CoinsModel.applyTransaction({
        userId, amount, reason: 'admin_grant', referenceId: null,
      });
      await AuditLogModel.record({
        userId: req.user.sub, action: 'coins_granted',
        metadata: { targetUserId: userId, amount }, ipAddress: req.ip,
      });
      return res.json({ message: 'Mega Coins concedidos.', newBalance: result.newBalance });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = AdminFinanceController;
