const UserModel = require('../models/userModel');
const SubscriptionModel = require('../models/subscriptionModel');
const CouponModel = require('../models/couponModel');
const StripeProvider = require('../services/paymentProviders/stripeProvider');
const AppleIapProvider = require('../services/paymentProviders/appleIapProvider');
const GoogleIapProvider = require('../services/paymentProviders/googleIapProvider');
const { PLANS } = require('../config/plans');

const SubscriptionController = {
  // GET /api/subscriptions/plans — usado pela tela de upgrade do app
  async listPlans(req, res) {
    const publicPlans = Object.entries(PLANS).map(([key, p]) => ({
      id: key,
      label: p.label,
      priceCents: p.priceCents,
      trialDays: p.trialDays || 0,
      features: p.features,
    }));
    return res.json({ plans: publicPlans });
  },

  // GET /api/subscriptions/me
  async myStatus(req, res, next) {
    try {
      const user = await UserModel.findById(req.user.sub);
      const subscription = await SubscriptionModel.findActiveByUser(user.id);
      return res.json({
        plan: user.plan,
        planExpiresAt: user.plan_expires_at,
        megaCoins: user.mega_coins,
        subscription,
      });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/subscriptions/checkout/stripe  { plan, couponCode? }
  // Fluxo web/desktop. No app mobile, iOS e Android usam IAP nativo (obrigatório pelas lojas).
  async createStripeCheckout(req, res, next) {
    try {
      const { plan, couponCode } = req.body;
      if (!PLANS[plan] || plan === 'free') return res.status(400).json({ error: 'Plano inválido.' });

      const user = await UserModel.findById(req.user.sub);

      let couponStripeId;
      if (couponCode) {
        const coupon = await CouponModel.findActiveByCode(couponCode);
        if (!coupon) return res.status(400).json({ error: 'Cupom inválido ou expirado.' });
        // Cupons de desconto percentual são espelhados como Coupon objects na Stripe
        // (criados previamente pelo admin com o mesmo código — ver adminFinanceController).
        couponStripeId = coupon.type === 'percent_off' ? coupon.code : undefined;
      }

      const session = await StripeProvider.createCheckoutSession({
        user,
        plan,
        successUrl: `${process.env.FRONTEND_URL}/assinatura/sucesso`,
        cancelUrl: `${process.env.FRONTEND_URL}/assinatura/cancelada`,
        couponStripeId,
      });

      return res.json({ checkoutUrl: session.url });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/subscriptions/cancel
  async cancel(req, res, next) {
    try {
      const user = await UserModel.findById(req.user.sub);
      const subscription = await SubscriptionModel.findActiveByUser(user.id);
      if (!subscription) return res.status(404).json({ error: 'Nenhuma assinatura ativa encontrada.' });

      if (subscription.provider === 'stripe') {
        await StripeProvider.cancelAtPeriodEnd(subscription.provider_subscription_id);
      } else {
        // Apple/Google: cancelamento é feito pelo usuário nas configurações
        // da própria loja — o backend só reflete o estado quando o webhook chegar.
        return res.status(400).json({
          error: 'Assinaturas feitas pela App Store ou Google Play precisam ser canceladas nas configurações da respectiva loja.',
        });
      }

      await SubscriptionModel.updateStatus(subscription.id, { cancelAtPeriodEnd: true });
      return res.json({ message: 'Assinatura será cancelada ao final do período atual.' });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/subscriptions/verify/apple  { signedTransactionInfo }
  // Chamado pelo app logo após uma compra bem-sucedida via StoreKit.
  async verifyApple(req, res, next) {
    try {
      const { signedTransactionInfo } = req.body;
      const transaction = AppleIapProvider.decodeSignedTransaction(signedTransactionInfo);
      const plan = AppleIapProvider.mapProductIdToPlan(transaction.productId);
      if (!plan) return res.status(400).json({ error: 'Produto não reconhecido.' });

      const user = await UserModel.findById(req.user.sub);
      const expiresAt = new Date(transaction.expiresDate);

      const subscription = await SubscriptionModel.create({
        userId: user.id,
        plan,
        status: 'active',
        provider: 'apple_iap',
        providerSubscriptionId: transaction.originalTransactionId,
        currentPeriodEnd: expiresAt,
      });
      await SubscriptionModel.syncUserPlan(user.id, plan, expiresAt);

      return res.json({ message: 'Assinatura ativada.', subscription });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/subscriptions/verify/google  { purchaseToken, subscriptionId }
  async verifyGoogle(req, res, next) {
    try {
      const { purchaseToken, subscriptionId } = req.body;
      const purchase = await GoogleIapProvider.verifySubscription({
        packageName: process.env.GOOGLE_PLAY_PACKAGE_NAME,
        subscriptionId,
        purchaseToken,
      });

      const plan = GoogleIapProvider.mapProductIdToPlan(subscriptionId);
      if (!plan) return res.status(400).json({ error: 'Produto não reconhecido.' });

      const user = await UserModel.findById(req.user.sub);
      const expiresAt = new Date(Number(purchase.expiryTimeMillis));

      const subscription = await SubscriptionModel.create({
        userId: user.id,
        plan,
        status: 'active',
        provider: 'google_iap',
        providerSubscriptionId: purchaseToken,
        currentPeriodEnd: expiresAt,
      });
      await SubscriptionModel.syncUserPlan(user.id, plan, expiresAt);

      return res.json({ message: 'Assinatura ativada.', subscription });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = SubscriptionController;
