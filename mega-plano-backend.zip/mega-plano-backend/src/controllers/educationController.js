const { GradeLevelModel, SubjectModel } = require('../models/educationStructureModel');
const { LessonModel, ProgressModel } = require('../models/lessonModel');
const UserModel = require('../models/userModel');
const XpService = require('../services/xpService');
const AchievementService = require('../services/achievementService');
const { planSatisfies } = require('../config/plans');
const { query } = require('../config/db');

const EducationController = {
  // GET /api/education/grade-levels?stage=elementary_1
  async listGradeLevels(req, res, next) {
    try {
      const levels = await GradeLevelModel.listByStage(req.query.stage);
      return res.json({ gradeLevels: levels });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/education/grade-levels/:id/subjects
  async listSubjects(req, res, next) {
    try {
      const subjects = await SubjectModel.listByGradeLevel(req.params.id);
      return res.json({ subjects });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/education/subjects/:id/lessons
  async listLessons(req, res, next) {
    try {
      const lessons = await LessonModel.listBySubject(req.params.id);
      return res.json({ lessons });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/education/subjects/:id/progress  (autenticado)
  async subjectProgress(req, res, next) {
    try {
      const summary = await ProgressModel.subjectProgressSummary(req.params.id, req.user.sub);
      return res.json({
        completed: Number(summary.completed_count),
        total: Number(summary.total_count),
      });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/education/lessons/:id  (autenticado — checa plano se a aula for premium)
  async getLesson(req, res, next) {
    try {
      const lesson = await LessonModel.findFullById(req.params.id);
      if (!lesson) return res.status(404).json({ error: 'Aula não encontrada.' });

      if (lesson.is_premium) {
        const user = await UserModel.findById(req.user.sub);
        if (!planSatisfies(user.plan, 'pro')) {
          return res.status(402).json({
            error: 'Esta aula é exclusiva para assinantes PRO ou ULTRA.',
            code: 'PLAN_UPGRADE_REQUIRED',
          });
        }
      }

      const exercises = await LessonModel.listExercises(lesson.id);
      const completed = await ProgressModel.isLessonCompleted(req.user.sub, lesson.id);

      return res.json({ lesson, exercises, completed });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/education/lessons/:id/complete  (autenticado)
  async completeLesson(req, res, next) {
    try {
      const lesson = await LessonModel.findFullById(req.params.id);
      if (!lesson) return res.status(404).json({ error: 'Aula não encontrada.' });

      const alreadyDone = await ProgressModel.isLessonCompleted(req.user.sub, lesson.id);
      await ProgressModel.markLessonCompleted(req.user.sub, lesson.id);

      let xpResult = null;
      if (!alreadyDone) {
        // XP só é concedido na primeira conclusão — evita farm infinito refazendo a mesma aula.
        xpResult = await XpService.grant({ userId: req.user.sub, amount: lesson.xp_reward, reason: 'lesson_completed', referenceId: lesson.id });
        await AchievementService.grantIfNew(req.user.sub, 'first_lesson');
        if (xpResult.streakDays === 7) await AchievementService.grantIfNew(req.user.sub, 'streak_7');
      }

      return res.json({ message: 'Aula concluída!', xp: xpResult });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/education/exercises/:id/answer  { answer }  (autenticado)
  async answerExercise(req, res, next) {
    try {
      const { answer } = req.body;
      const exercise = await LessonModel.findExerciseById(req.params.id);
      if (!exercise) return res.status(404).json({ error: 'Exercício não encontrado.' });

      const isCorrect = String(answer).trim().toLowerCase() === String(exercise.correct_answer).trim().toLowerCase();
      await ProgressModel.recordExerciseAttempt({ userId: req.user.sub, exerciseId: exercise.id, answerGiven: answer, isCorrect });

      let xpResult = null;
      if (isCorrect) {
        xpResult = await XpService.grant({ userId: req.user.sub, amount: exercise.xp_reward, reason: 'exercise_correct', referenceId: exercise.id });
      }

      return res.json({ isCorrect, explanation: exercise.explanation, xp: xpResult });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/education/mock-exams/:id  (autenticado)
  async getMockExam(req, res, next) {
    try {
      const { rows: examRows } = await query('SELECT * FROM mock_exams WHERE id = $1', [req.params.id]);
      const exam = examRows[0];
      if (!exam) return res.status(404).json({ error: 'Simulado não encontrado.' });

      const { rows: exercises } = await query(
        `SELECT e.id, e.type, e.question, e.options, e.xp_reward
         FROM mock_exam_exercises mee JOIN exercises e ON e.id = mee.exercise_id
         WHERE mee.mock_exam_id = $1 ORDER BY mee.sort_order`,
        [exam.id]
      );

      return res.json({ exam, exercises });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = EducationController;
