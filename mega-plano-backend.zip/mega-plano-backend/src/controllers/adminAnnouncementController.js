const { NotificationModel } = require('./notificationController');
const AuditLogModel = require('../models/auditLogModel');

const AdminAnnouncementController = {
  // POST /api/admin/announcements  { title, body, data? }
  async broadcast(req, res, next) {
    try {
      const { title, body, data } = req.body;
      if (!title?.trim()) return res.status(400).json({ error: 'Título é obrigatório.' });

      await NotificationModel.broadcastToAllUsers({ type: 'admin_announcement', title, body, data });
      await AuditLogModel.record({
        userId: req.user.sub, action: 'announcement_broadcast', metadata: { title }, ipAddress: req.ip,
      });

      return res.status(201).json({ message: 'Anúncio enviado para todos os usuários.' });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = AdminAnnouncementController;
