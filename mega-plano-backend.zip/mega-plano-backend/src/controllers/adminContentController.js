const { GradeLevelModel, SubjectModel } = require('../models/educationStructureModel');
const { LessonModel } = require('../models/lessonModel');
const { LanguageModel } = require('../models/languageModel');
const { GameModel } = require('./gameController');
const AuditLogModel = require('../models/auditLogModel');

// Loga toda escrita de conteúdo — não é tão sensível quanto banir usuário,
// mas ajuda a rastrear "quem mudou essa aula" quando algo quebra.
function logContentAction(req, action, metadata) {
  return AuditLogModel.record({ userId: req.user.sub, action, metadata, ipAddress: req.ip });
}

const AdminContentController = {
  // --- Educação ---
  async createGradeLevel(req, res, next) {
    try {
      const level = await GradeLevelModel.create(req.body);
      await logContentAction(req, 'grade_level_created', { id: level.id });
      return res.status(201).json({ gradeLevel: level });
    } catch (err) { next(err); }
  },

  async updateGradeLevel(req, res, next) {
    try {
      const level = await GradeLevelModel.update(req.params.id, req.body);
      if (!level) return res.status(404).json({ error: 'Série não encontrada.' });
      return res.json({ gradeLevel: level });
    } catch (err) { next(err); }
  },

  async deleteGradeLevel(req, res, next) {
    try {
      await GradeLevelModel.delete(req.params.id);
      await logContentAction(req, 'grade_level_deleted', { id: req.params.id });
      return res.json({ message: 'Série removida.' });
    } catch (err) { next(err); }
  },

  async createSubject(req, res, next) {
    try {
      const subject = await SubjectModel.create(req.body);
      await logContentAction(req, 'subject_created', { id: subject.id });
      return res.status(201).json({ subject });
    } catch (err) { next(err); }
  },

  async updateSubject(req, res, next) {
    try {
      const subject = await SubjectModel.update(req.params.id, req.body);
      if (!subject) return res.status(404).json({ error: 'Matéria não encontrada.' });
      return res.json({ subject });
    } catch (err) { next(err); }
  },

  async deleteSubject(req, res, next) {
    try {
      await SubjectModel.delete(req.params.id);
      await logContentAction(req, 'subject_deleted', { id: req.params.id });
      return res.json({ message: 'Matéria removida.' });
    } catch (err) { next(err); }
  },

  async createLesson(req, res, next) {
    try {
      const lesson = await LessonModel.create(req.body);
      await logContentAction(req, 'lesson_created', { id: lesson.id, title: lesson.title });
      return res.status(201).json({ lesson });
    } catch (err) { next(err); }
  },

  async updateLesson(req, res, next) {
    try {
      const lesson = await LessonModel.update(req.params.id, req.body);
      if (!lesson) return res.status(404).json({ error: 'Aula não encontrada.' });
      await logContentAction(req, 'lesson_updated', { id: lesson.id });
      return res.json({ lesson });
    } catch (err) { next(err); }
  },

  async deleteLesson(req, res, next) {
    try {
      await LessonModel.delete(req.params.id);
      await logContentAction(req, 'lesson_deleted', { id: req.params.id });
      return res.json({ message: 'Aula removida.' });
    } catch (err) { next(err); }
  },

  async createExercise(req, res, next) {
    try {
      const exercise = await LessonModel.createExercise(req.body);
      return res.status(201).json({ exercise });
    } catch (err) { next(err); }
  },

  async updateExercise(req, res, next) {
    try {
      const exercise = await LessonModel.updateExercise(req.params.id, req.body);
      if (!exercise) return res.status(404).json({ error: 'Exercício não encontrado.' });
      return res.json({ exercise });
    } catch (err) { next(err); }
  },

  async deleteExercise(req, res, next) {
    try {
      await LessonModel.deleteExercise(req.params.id);
      return res.json({ message: 'Exercício removido.' });
    } catch (err) { next(err); }
  },

  // --- Idiomas ---
  async createLanguage(req, res, next) {
    try {
      const language = await LanguageModel.createLanguage(req.body);
      await logContentAction(req, 'language_created', { id: language.id, name: language.name });
      return res.status(201).json({ language });
    } catch (err) { next(err); }
  },

  async createLanguageUnit(req, res, next) {
    try {
      const unit = await LanguageModel.createUnit(req.body);
      await logContentAction(req, 'language_unit_created', { id: unit.id });
      return res.status(201).json({ unit });
    } catch (err) { next(err); }
  },

  async updateLanguageUnit(req, res, next) {
    try {
      const unit = await LanguageModel.updateUnit(req.params.id, req.body);
      if (!unit) return res.status(404).json({ error: 'Unidade não encontrada.' });
      return res.json({ unit });
    } catch (err) { next(err); }
  },

  async deleteLanguageUnit(req, res, next) {
    try {
      await LanguageModel.deleteUnit(req.params.id);
      await logContentAction(req, 'language_unit_deleted', { id: req.params.id });
      return res.json({ message: 'Unidade removida.' });
    } catch (err) { next(err); }
  },

  async createVocabularyItem(req, res, next) {
    try {
      const item = await LanguageModel.createVocabularyItem(req.body);
      return res.status(201).json({ item });
    } catch (err) { next(err); }
  },

  async deleteVocabularyItem(req, res, next) {
    try {
      await LanguageModel.deleteVocabularyItem(req.params.id);
      return res.json({ message: 'Item de vocabulário removido.' });
    } catch (err) { next(err); }
  },

  // --- Games (Gaming Settings) ---
  async createGame(req, res, next) {
    try {
      const game = await GameModel.create(req.body);
      await logContentAction(req, 'game_created', { id: game.id, slug: game.slug });
      return res.status(201).json({ game });
    } catch (err) { next(err); }
  },

  async toggleGame(req, res, next) {
    try {
      await GameModel.setActive(req.params.id, req.body.active);
      return res.json({ message: 'Jogo atualizado.' });
    } catch (err) { next(err); }
  },

  async createGameGuide(req, res, next) {
    try {
      const guide = await GameModel.createGuide(req.body);
      await logContentAction(req, 'game_guide_created', { id: guide.id, title: guide.title });
      return res.status(201).json({ guide });
    } catch (err) { next(err); }
  },

  async updateGameGuide(req, res, next) {
    try {
      const guide = await GameModel.updateGuide(req.params.id, req.body);
      if (!guide) return res.status(404).json({ error: 'Guia não encontrado.' });
      return res.json({ guide });
    } catch (err) { next(err); }
  },

  async deleteGameGuide(req, res, next) {
    try {
      await GameModel.deleteGuide(req.params.id);
      await logContentAction(req, 'game_guide_deleted', { id: req.params.id });
      return res.json({ message: 'Guia removido.' });
    } catch (err) { next(err); }
  },
};

module.exports = AdminContentController;
