const StoreModel = require('../models/storeModel');
const CoinsModel = require('../models/coinsModel');
const UserModel = require('../models/userModel');
const { planSatisfies } = require('../config/plans');

const StoreController = {
  // GET /api/store/products?category=theme
  async listProducts(req, res, next) {
    try {
      const products = await StoreModel.listActiveProducts({ category: req.query.category });
      return res.json({ products });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/store/my-purchases
  async myPurchases(req, res, next) {
    try {
      const purchases = await StoreModel.listUserPurchases(req.user.sub);
      return res.json({ purchases });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/store/purchase/:productId  — compra com Mega Coins (compra com
  // dinheiro real segue o mesmo padrão do coinsController.buyWithPix, trocando a descrição)
  async purchaseWithCoins(req, res, next) {
    try {
      const product = await StoreModel.findById(req.params.productId);
      if (!product || !product.active) return res.status(404).json({ error: 'Produto não encontrado.' });
      if (product.currency !== 'mega_coins') {
        return res.status(400).json({ error: 'Este produto não pode ser comprado com Mega Coins.' });
      }

      const user = await UserModel.findById(req.user.sub);

      if (product.requires_plan && !planSatisfies(user.plan, product.requires_plan)) {
        return res.status(402).json({
          error: `Este item exige o plano ${product.requires_plan.toUpperCase()} ou superior.`,
          code: 'PLAN_UPGRADE_REQUIRED',
        });
      }

      const alreadyOwns = await StoreModel.userAlreadyOwns(user.id, product.id);
      if (alreadyOwns) return res.status(409).json({ error: 'Você já possui este item.' });

      await CoinsModel.applyTransaction({
        userId: user.id,
        amount: -product.price_coins,
        reason: 'store_purchase',
        referenceId: product.id,
      });

      const purchase = await StoreModel.recordPurchase({ userId: user.id, productId: product.id });
      return res.status(201).json({ message: 'Compra realizada!', purchase });
    } catch (err) {
      if (err.message.includes('insuficiente')) {
        return res.status(402).json({ error: 'Saldo de Mega Coins insuficiente.' });
      }
      next(err);
    }
  },
};

module.exports = StoreController;
