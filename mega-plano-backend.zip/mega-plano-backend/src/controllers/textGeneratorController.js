const { query } = require('../config/db');
const AiService = require('../services/aiService');
const UserModel = require('../models/userModel');

const GeneratedTextModel = {
  async save({ userId, type, inputData, outputContent }) {
    const { rows } = await query(
      `INSERT INTO generated_texts (user_id, type, input_data, output_content) VALUES ($1,$2,$3,$4) RETURNING *`,
      [userId, type, inputData, outputContent]
    );
    return rows[0];
  },

  async listForUser(userId, type) {
    const params = [userId];
    let extra = '';
    if (type) { params.push(type); extra = `AND type = $${params.length}`; }
    const { rows } = await query(
      `SELECT * FROM generated_texts WHERE user_id = $1 ${extra} ORDER BY created_at DESC LIMIT 50`,
      params
    );
    return rows;
  },
};

// Cada tipo tem seu próprio prompt-base — o campo `inputData` do usuário é
// interpolado como contexto estruturado, não como comando livre, pra manter
// o resultado no formato esperado (CV, carta, etc).
const PROMPT_BUILDERS = {
  cv: (d) => `Crie um currículo profissional em português para: ${d.name}, cargo pretendido: ${d.targetRole}. Experiências: ${d.experience}. Formação: ${d.education}. Habilidades: ${d.skills}. Formate em seções claras (Resumo, Experiência, Formação, Habilidades).`,
  cover_letter: (d) => `Escreva uma carta de apresentação profissional em português para a vaga de ${d.targetRole} na empresa ${d.company}. Pontos a destacar: ${d.highlights}. Tom: ${d.tone || 'formal e objetivo'}.`,
  appeal_letter: (d) => `Escreva um recurso/carta de contestação em português sobre: ${d.subject}. Argumentos principais: ${d.arguments}. Destinatário: ${d.recipient}. Tom formal e respeitoso.`,
  email: (d) => `Escreva um e-mail em português com o assunto "${d.subject}", direcionado a ${d.recipient}. Contexto/objetivo: ${d.context}. Tom: ${d.tone || 'profissional'}.`,
  application: (d) => `Escreva um requerimento/petição formal em português sobre: ${d.subject}, destinado a ${d.recipient}. Detalhes: ${d.details}.`,
  report: (d) => `Escreva um relatório em português sobre: ${d.topic}. Pontos a cobrir: ${d.points}. Formate com seções e conclusão.`,
  social_media_post: (d) => `Escreva um post para ${d.platform || 'redes sociais'} em português sobre: ${d.topic}. Tom: ${d.tone || 'envolvente'}. ${d.includeHashtags ? 'Inclua hashtags relevantes.' : ''}`,
  professional_message: (d) => `Escreva uma mensagem profissional em português para ${d.recipient} sobre: ${d.context}. Tom: ${d.tone || 'cordial e direto'}.`,
  custom: (d) => d.prompt,
};

const TextGeneratorController = {
  // GET /api/text-generator/history?type=cv  (autenticado)
  async history(req, res, next) {
    try {
      const texts = await GeneratedTextModel.listForUser(req.user.sub, req.query.type);
      return res.json({ texts });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/text-generator/generate  { type, inputData }  (autenticado)
  async generate(req, res, next) {
    try {
      const { type, inputData } = req.body;
      const buildPrompt = PROMPT_BUILDERS[type];
      if (!buildPrompt) return res.status(400).json({ error: 'Tipo de texto inválido.' });

      const prompt = buildPrompt(inputData || {});
      if (!prompt?.trim()) return res.status(400).json({ error: 'Dados insuficientes para gerar o texto.' });

      const user = await UserModel.findById(req.user.sub);
      const output = await AiService.complete({
        prompt,
        plan: user.plan,
        systemPrompt: 'Você é um assistente de redação profissional. Escreva em português do Brasil, com formatação clara e pronta para uso — sem comentários extras antes ou depois do texto solicitado.',
      });

      const saved = await GeneratedTextModel.save({ userId: user.id, type, inputData, outputContent: output });
      return res.status(201).json({ text: saved });
    } catch (err) {
      if (err.message.includes('ANTHROPIC_API_KEY')) {
        return res.status(503).json({ error: 'Gerador de textos temporariamente indisponível.' });
      }
      next(err);
    }
  },
};

module.exports = { GeneratedTextModel, TextGeneratorController };
