const { query } = require('../config/db');

const FavoriteModel = {
  async add(userId, contentType, contentId) {
    const { rows } = await query(
      `INSERT INTO favorites (user_id, content_type, content_id) VALUES ($1,$2,$3)
       ON CONFLICT (user_id, content_type, content_id) DO NOTHING RETURNING *`,
      [userId, contentType, contentId]
    );
    return rows[0] || null;
  },

  async remove(userId, contentType, contentId) {
    await query(
      'DELETE FROM favorites WHERE user_id = $1 AND content_type = $2 AND content_id = $3',
      [userId, contentType, contentId]
    );
  },

  async list(userId, contentType) {
    const params = [userId];
    let extra = '';
    if (contentType) { params.push(contentType); extra = `AND content_type = $${params.length}`; }
    const { rows } = await query(
      `SELECT * FROM favorites WHERE user_id = $1 ${extra} ORDER BY created_at DESC`,
      params
    );
    return rows;
  },
};

const FavoriteController = {
  // GET /api/favorites?type=lesson  (autenticado)
  async list(req, res, next) {
    try {
      const favorites = await FavoriteModel.list(req.user.sub, req.query.type);
      return res.json({ favorites });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/favorites  { contentType, contentId }  (autenticado)
  async add(req, res, next) {
    try {
      const { contentType, contentId } = req.body;
      const favorite = await FavoriteModel.add(req.user.sub, contentType, contentId);
      return res.status(201).json({ favorite });
    } catch (err) {
      next(err);
    }
  },

  // DELETE /api/favorites  { contentType, contentId }  (autenticado)
  async remove(req, res, next) {
    try {
      const { contentType, contentId } = req.body;
      await FavoriteModel.remove(req.user.sub, contentType, contentId);
      return res.json({ message: 'Removido dos favoritos.' });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = { FavoriteModel, FavoriteController };
