const CoinsModel = require('../models/coinsModel');
const PaymentModel = require('../models/paymentModel');
const PixProvider = require('../services/paymentProviders/pixProvider');
const UserModel = require('../models/userModel');

// Pacotes fixos de compra de moedas — poderiam virar tabela no banco no
// futuro, mas como fixed content isso é suficiente e mais simples de administrar.
const COIN_PACKS = {
  pack_small: { coins: 500, priceCents: 990 },
  pack_medium: { coins: 1500, priceCents: 2490 },
  pack_large: { coins: 4000, priceCents: 4990 },
};

const CoinsController = {
  // GET /api/coins/balance
  async balance(req, res, next) {
    try {
      const balance = await CoinsModel.getBalance(req.user.sub);
      return res.json({ megaCoins: balance });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/coins/history
  async history(req, res, next) {
    try {
      const history = await CoinsModel.listHistory(req.user.sub);
      return res.json({ history });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/coins/buy  { packId }  → gera cobrança PIX
  // (para cartão, o mesmo pacote pode ser vendido via Stripe Checkout em modo 'payment' — omitido aqui por brevidade, mesmo padrão do subscriptionController)
  async buyWithPix(req, res, next) {
    try {
      const { packId } = req.body;
      const pack = COIN_PACKS[packId];
      if (!pack) return res.status(400).json({ error: 'Pacote inválido.' });

      const user = await UserModel.findById(req.user.sub);
      const pix = await PixProvider.createPixPayment({
        amountCents: pack.priceCents,
        description: `MEGA PLANO — ${pack.coins} Mega Coins`,
        payerEmail: user.email,
        externalReference: `coinpack:${user.id}:${packId}:${Date.now()}`,
      });

      await PaymentModel.create({
        userId: user.id,
        provider: 'mercado_pago_pix',
        providerPaymentId: pix.providerPaymentId,
        status: 'pending',
        amountCents: pack.priceCents,
        description: `Pacote de Mega Coins: ${pack.coins}`,
        metadata: { type: 'coin_pack', coinsAmount: pack.coins },
      });

      return res.json({
        qrCode: pix.qrCode,
        qrCodeBase64: pix.qrCodeBase64,
        expiresAt: pix.expiresAt,
        message: 'Escaneie o QR code para pagar via PIX. Os Mega Coins são creditados automaticamente após a confirmação.',
      });
    } catch (err) {
      next(err);
    }
  },

  // Usado internamente por outros módulos (aulas, desafios, login diário, conquistas)
  // para creditar coins — não exposto como rota pública.
  async grant({ userId, amount, reason, referenceId }) {
    return CoinsModel.applyTransaction({ userId, amount, reason, referenceId });
  },
};

module.exports = CoinsController;
