const { LanguageModel, FlashcardModel } = require('../models/languageModel');
const UserModel = require('../models/userModel');
const XpService = require('../services/xpService');
const AchievementService = require('../services/achievementService');
const { planSatisfies } = require('../config/plans');

const LanguageController = {
  // GET /api/languages
  async listLanguages(req, res, next) {
    try {
      const languages = await LanguageModel.listAll();
      return res.json({ languages });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/languages/:id/units?type=vocabulary
  async listUnits(req, res, next) {
    try {
      const units = await LanguageModel.listUnits(req.params.id, req.query.type);
      return res.json({ units });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/languages/units/:id  (autenticado)
  async getUnit(req, res, next) {
    try {
      const unit = await LanguageModel.findUnitById(req.params.id);
      if (!unit) return res.status(404).json({ error: 'Unidade não encontrada.' });

      if (unit.is_premium) {
        const user = await UserModel.findById(req.user.sub);
        if (!planSatisfies(user.plan, 'pro')) {
          return res.status(402).json({ error: 'Esta unidade é exclusiva PRO/ULTRA.', code: 'PLAN_UPGRADE_REQUIRED' });
        }
      }

      const vocabulary = await LanguageModel.listVocabulary(unit.id);
      const completed = await LanguageModel.isUnitCompleted(req.user.sub, unit.id);

      return res.json({ unit, vocabulary, completed });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/languages/units/:id/complete  (autenticado)
  async completeUnit(req, res, next) {
    try {
      const unit = await LanguageModel.findUnitById(req.params.id);
      if (!unit) return res.status(404).json({ error: 'Unidade não encontrada.' });

      const alreadyDone = await LanguageModel.isUnitCompleted(req.user.sub, unit.id);
      await LanguageModel.markUnitCompleted(req.user.sub, unit.id);

      let xpResult = null;
      if (!alreadyDone) {
        xpResult = await XpService.grant({ userId: req.user.sub, amount: unit.xp_reward, reason: 'language_unit_completed', referenceId: unit.id });
        await LanguageModel.upsertUserProgress(req.user.sub, unit.language_id, { xpDelta: unit.xp_reward });
        await AchievementService.grantIfNew(req.user.sub, 'first_language_unit');
      }

      return res.json({ message: 'Unidade concluída!', xp: xpResult });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/languages/:id/progress  (autenticado)
  async myProgress(req, res, next) {
    try {
      const progress = await LanguageModel.getUserProgress(req.user.sub, req.params.id);
      return res.json({ progress: progress || { current_level: 'A1', xp_earned: 0 } });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/languages/certificates  (autenticado)
  async myCertificates(req, res, next) {
    try {
      const certificates = await LanguageModel.listCertificates(req.user.sub);
      return res.json({ certificates });
    } catch (err) {
      next(err);
    }
  },

  // --- Flashcards ---

  // GET /api/languages/flashcard-decks/:deckId/review  (autenticado)
  async flashcardsDue(req, res, next) {
    try {
      const cards = await FlashcardModel.listDueForReview(req.user.sub, req.params.deckId);
      return res.json({ cards });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/languages/flashcards/:id/review  { correct }  (autenticado)
  async reviewFlashcard(req, res, next) {
    try {
      const progress = await FlashcardModel.recordReview(req.user.sub, req.params.id, !!req.body.correct);
      return res.json({ progress });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = LanguageController;
