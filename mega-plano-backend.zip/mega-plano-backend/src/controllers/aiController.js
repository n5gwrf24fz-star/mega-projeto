const { AiConversationModel, AiMessageModel } = require('../models/aiConversationModel');
const UserModel = require('../models/userModel');
const AiService = require('../services/aiService');

// Quantas mensagens anteriores mandar como contexto pra IA — limite evita
// custo/latência crescendo sem parar em conversas muito longas.
const MAX_HISTORY_MESSAGES = 20;

const AiController = {
  // GET /api/ai/conversations  (autenticado)
  async listConversations(req, res, next) {
    try {
      const conversations = await AiConversationModel.listForUser(req.user.sub);
      return res.json({ conversations });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/ai/conversations/:id  (autenticado)
  async getConversation(req, res, next) {
    try {
      const conversation = await AiConversationModel.findById(req.params.id, req.user.sub);
      if (!conversation) return res.status(404).json({ error: 'Conversa não encontrada.' });
      const messages = await AiMessageModel.listForConversation(conversation.id);
      return res.json({ conversation, messages });
    } catch (err) {
      next(err);
    }
  },

  // DELETE /api/ai/conversations/:id  (autenticado)
  async deleteConversation(req, res, next) {
    try {
      await AiConversationModel.delete(req.params.id, req.user.sub);
      return res.json({ message: 'Conversa apagada.' });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/ai/conversations/:id/messages  { content }  (autenticado, sob aiUsageLimit)
  // Se :id for "new", cria uma conversa nova primeiro.
  async sendMessage(req, res, next) {
    try {
      const { content, context } = req.body;
      if (!content?.trim()) return res.status(400).json({ error: 'Mensagem vazia.' });

      let conversation;
      if (req.params.id === 'new') {
        conversation = await AiConversationModel.create(req.user.sub, context);
      } else {
        conversation = await AiConversationModel.findById(req.params.id, req.user.sub);
        if (!conversation) return res.status(404).json({ error: 'Conversa não encontrada.' });
      }

      await AiMessageModel.add(conversation.id, 'user', content);
      await AiConversationModel.renameIfDefault(conversation.id, content);

      const history = await AiMessageModel.listForConversation(conversation.id);
      const trimmedHistory = history.slice(-MAX_HISTORY_MESSAGES);

      const user = await UserModel.findById(req.user.sub);
      const replyText = await AiService.sendMessage({
        history: trimmedHistory.map((m) => ({ role: m.role, content: m.content })),
        context: conversation.context,
        plan: user.plan,
      });

      const assistantMessage = await AiMessageModel.add(conversation.id, 'assistant', replyText);
      await AiConversationModel.touch(conversation.id);

      return res.json({ conversationId: conversation.id, message: assistantMessage });
    } catch (err) {
      if (err.message.includes('ANTHROPIC_API_KEY')) {
        return res.status(503).json({ error: 'Mega IA temporariamente indisponível.' });
      }
      next(err);
    }
  },
};

module.exports = AiController;
