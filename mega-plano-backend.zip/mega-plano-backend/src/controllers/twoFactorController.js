const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const { query } = require('../config/db');
const UserModel = require('../models/userModel');
const SessionModel = require('../models/sessionModel');
const { signAccessToken, signRefreshToken } = require('../utils/jwt');
const { verifyTempTwoFactorToken } = require('../utils/twoFactorToken');

function refreshExpiryDate() {
  const days = parseInt((process.env.JWT_REFRESH_EXPIRES || '30d').replace('d', ''), 10);
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
}

const TwoFactorController = {
  // POST /api/auth/2fa/setup  (autenticado)
  // Gera um segredo novo e devolve um QR code para escanear no Google
  // Authenticator / Authy. O 2FA só passa a valer de fato depois do /enable.
  async setup(req, res, next) {
    try {
      const secret = speakeasy.generateSecret({
        name: `${process.env.TWO_FACTOR_APP_NAME || 'MEGA PLANO'} (${req.user.email})`,
      });

      // Guarda o segredo ainda como pendente — só é "oficializado" no enable.
      await query('UPDATE users SET two_factor_secret = $1 WHERE id = $2', [secret.base32, req.user.sub]);

      const qrCodeDataUrl = await qrcode.toDataURL(secret.otpauth_url);

      return res.json({
        message: 'Escaneie o QR code no seu app autenticador e confirme com um código em /2fa/enable.',
        qrCodeDataUrl,
        manualEntryKey: secret.base32,
      });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/auth/2fa/enable  { code }  (autenticado)
  async enable(req, res, next) {
    try {
      const { code } = req.body;
      const user = await UserModel.findById(req.user.sub);

      if (!user.two_factor_secret) {
        return res.status(400).json({ error: 'Chame /2fa/setup antes de ativar.' });
      }

      const valid = speakeasy.totp.verify({
        secret: user.two_factor_secret,
        encoding: 'base32',
        token: code,
        window: 1, // tolera 30s de diferença de relógio
      });

      if (!valid) return res.status(400).json({ error: 'Código incorreto.' });

      await query('UPDATE users SET two_factor_enabled = TRUE WHERE id = $1', [user.id]);
      return res.json({ message: '2FA ativado com sucesso.' });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/auth/2fa/disable  { code }  (autenticado)
  async disable(req, res, next) {
    try {
      const { code } = req.body;
      const user = await UserModel.findById(req.user.sub);

      const valid = speakeasy.totp.verify({
        secret: user.two_factor_secret,
        encoding: 'base32',
        token: code,
        window: 1,
      });
      if (!valid) return res.status(400).json({ error: 'Código incorreto.' });

      await query(
        'UPDATE users SET two_factor_enabled = FALSE, two_factor_secret = NULL WHERE id = $1',
        [user.id]
      );
      return res.json({ message: '2FA desativado.' });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/auth/2fa/login-verify  { tempToken, code }
  // Segunda etapa do login: troca o token temporário + código TOTP pelos
  // tokens de acesso finais.
  async verifyLogin(req, res, next) {
    try {
      const { tempToken, code } = req.body;

      let payload;
      try {
        payload = verifyTempTwoFactorToken(tempToken);
      } catch {
        return res.status(401).json({ error: 'Sessão de login expirada, faça login novamente.' });
      }

      const user = await UserModel.findById(payload.sub);
      if (!user || !user.two_factor_enabled) {
        return res.status(400).json({ error: '2FA não está ativo para esta conta.' });
      }

      const valid = speakeasy.totp.verify({
        secret: user.two_factor_secret,
        encoding: 'base32',
        token: code,
        window: 1,
      });
      if (!valid) return res.status(401).json({ error: 'Código incorreto.' });

      const accessToken = signAccessToken(user);
      const refreshToken = signRefreshToken(user);

      await SessionModel.create({
        userId: user.id,
        refreshToken,
        deviceInfo: req.headers['user-agent'] || 'desconhecido',
        ipAddress: req.ip,
        expiresAt: refreshExpiryDate(),
      });

      return res.json({ accessToken, refreshToken, user: UserModel.toPublic(user) });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = TwoFactorController;
