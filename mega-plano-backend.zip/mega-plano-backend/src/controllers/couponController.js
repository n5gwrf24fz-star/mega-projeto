const CouponModel = require('../models/couponModel');
const CoinsModel = require('../models/coinsModel');
const SubscriptionModel = require('../models/subscriptionModel');
const UserModel = require('../models/userModel');

const CouponController = {
  // POST /api/coupons/redeem  { code }
  async redeem(req, res, next) {
    try {
      const { code } = req.body;
      const coupon = await CouponModel.findActiveByCode(code);
      if (!coupon) return res.status(404).json({ error: 'Cupom inválido ou expirado.' });

      const redeemed = await CouponModel.redeem(coupon, req.user.sub);

      let resultMessage = 'Cupom aplicado!';
      switch (redeemed.type) {
        case 'mega_coins':
          await CoinsModel.applyTransaction({
            userId: req.user.sub,
            amount: redeemed.value,
            reason: 'coupon_redemption',
            referenceId: redeemed.id,
          });
          resultMessage = `${redeemed.value} Mega Coins creditados!`;
          break;

        case 'flat_days_pro': {
          const user = await UserModel.findById(req.user.sub);
          const base = user.plan_expires_at && new Date(user.plan_expires_at) > new Date()
            ? new Date(user.plan_expires_at)
            : new Date();
          const newExpiry = new Date(base.getTime() + redeemed.value * 24 * 60 * 60 * 1000);
          await SubscriptionModel.syncUserPlan(user.id, 'pro', newExpiry);
          resultMessage = `${redeemed.value} dias de PRO adicionados!`;
          break;
        }

        case 'percent_off':
          // Aplicado no momento do checkout (ver subscriptionController.createStripeCheckout),
          // aqui só confirmamos que o código é válido para o usuário usar em seguida.
          resultMessage = `Cupom de ${redeemed.value}% OFF pronto para uso no checkout.`;
          break;

        case 'course_unlock':
          // TODO: integrar com o módulo de Educação (Fase 5) para liberar o curso referenciado.
          resultMessage = 'Curso desbloqueado!';
          break;
      }

      return res.json({ message: resultMessage, coupon: { code: redeemed.code, type: redeemed.type, value: redeemed.value } });
    } catch (err) {
      if (err.message.includes('esgotado') || err.message.includes('já usou') || err.message.includes('inativo')) {
        return res.status(409).json({ error: err.message });
      }
      next(err);
    }
  },
};

module.exports = CouponController;
