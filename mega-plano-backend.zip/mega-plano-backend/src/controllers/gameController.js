const { query } = require('../config/db');

const GameModel = {
  async listActive() {
    const { rows } = await query('SELECT * FROM games WHERE active = TRUE ORDER BY name');
    return rows;
  },

  async findBySlug(slug) {
    const { rows } = await query('SELECT * FROM games WHERE slug = $1', [slug]);
    return rows[0] || null;
  },

  async listGuides(gameId, category) {
    const params = [gameId];
    let extra = '';
    if (category) { params.push(category); extra = `AND category = $${params.length}`; }
    const { rows } = await query(
      `SELECT * FROM game_guides WHERE game_id = $1 ${extra} ORDER BY published_at DESC`,
      params
    );
    return rows;
  },

  async saveSensitivityConfig({ userId, gameId, deviceModel, settings }) {
    const { rows } = await query(
      `INSERT INTO user_sensitivity_configs (user_id, game_id, device_model, settings)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [userId, gameId, deviceModel, settings]
    );
    return rows[0];
  },

  async listUserSensitivityConfigs(userId, gameId) {
    const { rows } = await query(
      'SELECT * FROM user_sensitivity_configs WHERE user_id = $1 AND game_id = $2 ORDER BY created_at DESC',
      [userId, gameId]
    );
    return rows;
  },

  // --- Escrita (Gaming Settings do admin) ---

  async create({ slug, name, iconUrl }) {
    const { rows } = await query('INSERT INTO games (slug, name, icon_url) VALUES ($1,$2,$3) RETURNING *', [slug, name, iconUrl || null]);
    return rows[0];
  },

  async setActive(id, active) {
    await query('UPDATE games SET active = $1 WHERE id = $2', [active, id]);
  },

  async createGuide({ gameId, category, title, content, deviceModel, isPremium }) {
    const { rows } = await query(
      `INSERT INTO game_guides (game_id, category, title, content, device_model, is_premium)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [gameId, category, title, content, deviceModel || null, isPremium ?? false]
    );
    return rows[0];
  },

  async updateGuide(id, fields) {
    const { rows } = await query(
      `UPDATE game_guides SET title = COALESCE($2, title), content = COALESCE($3, content), is_premium = COALESCE($4, is_premium)
       WHERE id = $1 RETURNING *`,
      [id, fields.title, fields.content, fields.isPremium]
    );
    return rows[0] || null;
  },

  async deleteGuide(id) {
    await query('DELETE FROM game_guides WHERE id = $1', [id]);
  },
};

const GameController = {
  // GET /api/games
  async listGames(req, res, next) {
    try {
      const games = await GameModel.listActive();
      return res.json({ games });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/games/:slug/guides?category=sensitivity
  async listGuides(req, res, next) {
    try {
      const game = await GameModel.findBySlug(req.params.slug);
      if (!game) return res.status(404).json({ error: 'Jogo não encontrado.' });
      const guides = await GameModel.listGuides(game.id, req.query.category);
      return res.json({ game, guides });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/games/:slug/sensitivity  { deviceModel, settings }  (autenticado)
  // `settings` é gerado no app (algoritmo local) — o backend só guarda o
  // histórico pra o usuário poder comparar/recuperar configs antigas.
  async saveSensitivity(req, res, next) {
    try {
      const game = await GameModel.findBySlug(req.params.slug);
      if (!game) return res.status(404).json({ error: 'Jogo não encontrado.' });

      const config = await GameModel.saveSensitivityConfig({
        userId: req.user.sub,
        gameId: game.id,
        deviceModel: req.body.deviceModel,
        settings: req.body.settings,
      });
      return res.status(201).json({ config });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/games/:slug/sensitivity  (autenticado)
  async listSensitivityConfigs(req, res, next) {
    try {
      const game = await GameModel.findBySlug(req.params.slug);
      if (!game) return res.status(404).json({ error: 'Jogo não encontrado.' });
      const configs = await GameModel.listUserSensitivityConfigs(req.user.sub, game.id);
      return res.json({ configs });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = { GameModel, GameController };
