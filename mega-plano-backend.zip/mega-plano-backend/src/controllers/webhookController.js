const StripeProvider = require('../services/paymentProviders/stripeProvider');
const AppleIapProvider = require('../services/paymentProviders/appleIapProvider');
const GoogleIapProvider = require('../services/paymentProviders/googleIapProvider');
const PixProvider = require('../services/paymentProviders/pixProvider');
const SubscriptionModel = require('../models/subscriptionModel');
const PaymentModel = require('../models/paymentModel');
const CoinsModel = require('../models/coinsModel');
const StoreModel = require('../models/storeModel');

const WebhookController = {
  // POST /api/payments/webhooks/stripe
  // Fonte da verdade do estado real das assinaturas Stripe. Nunca confie
  // apenas no retorno do checkout no front — o webhook é o que garante
  // consistência mesmo se o usuário fechar o navegador no meio do fluxo.
  async stripe(req, res) {
    let event;
    try {
      event = StripeProvider.constructWebhookEvent(req.body, req.headers['stripe-signature']);
    } catch (err) {
      return res.status(400).send(`Assinatura de webhook inválida: ${err.message}`);
    }

    try {
      switch (event.type) {
        case 'checkout.session.completed': {
          const session = event.data.object;
          const { megaPlanoUserId, plan } = session.metadata;

          const subscription = await SubscriptionModel.create({
            userId: megaPlanoUserId,
            plan,
            status: session.subscription ? 'trialing' : 'active',
            provider: 'stripe',
            providerSubscriptionId: session.subscription,
          });

          await PaymentModel.create({
            userId: megaPlanoUserId,
            subscriptionId: subscription.id,
            provider: 'stripe',
            providerPaymentId: session.id,
            status: 'succeeded',
            amountCents: session.amount_total,
            currency: session.currency?.toUpperCase(),
            description: `Assinatura ${plan}`,
          });
          break;
        }

        case 'invoice.paid': {
          const invoice = event.data.object;
          const subscription = await SubscriptionModel.findByProviderSubscriptionId(invoice.subscription);
          if (subscription) {
            await SubscriptionModel.updateStatus(subscription.id, {
              status: 'active',
              currentPeriodStart: new Date(invoice.period_start * 1000),
              currentPeriodEnd: new Date(invoice.period_end * 1000),
            });
            await SubscriptionModel.syncUserPlan(subscription.user_id, subscription.plan, new Date(invoice.period_end * 1000));
            await PaymentModel.create({
              userId: subscription.user_id,
              subscriptionId: subscription.id,
              provider: 'stripe',
              providerPaymentId: invoice.id,
              status: 'succeeded',
              amountCents: invoice.amount_paid,
              currency: invoice.currency?.toUpperCase(),
              description: 'Renovação de assinatura',
            });
          }
          break;
        }

        case 'invoice.payment_failed': {
          const invoice = event.data.object;
          const subscription = await SubscriptionModel.findByProviderSubscriptionId(invoice.subscription);
          if (subscription) {
            await SubscriptionModel.updateStatus(subscription.id, { status: 'past_due' });
          }
          break;
        }

        case 'customer.subscription.deleted': {
          const sub = event.data.object;
          const subscription = await SubscriptionModel.findByProviderSubscriptionId(sub.id);
          if (subscription) {
            await SubscriptionModel.updateStatus(subscription.id, { status: 'canceled', canceledAt: new Date() });
            await SubscriptionModel.syncUserPlan(subscription.user_id, 'free', null);
          }
          break;
        }

        default:
          break; // eventos não tratados são ignorados de propósito
      }

      return res.json({ received: true });
    } catch (err) {
      console.error('Erro processando webhook Stripe:', err);
      return res.status(500).json({ error: 'Erro ao processar webhook.' });
    }
  },

  // POST /api/payments/webhooks/apple
  async apple(req, res) {
    try {
      const notification = AppleIapProvider.decodeServerNotification(req.body.signedPayload);
      const transaction = AppleIapProvider.decodeSignedTransaction(notification.data.signedTransactionInfo);

      const subscription = await SubscriptionModel.findByProviderSubscriptionId(transaction.originalTransactionId);
      if (subscription) {
        const statusMap = {
          DID_RENEW: 'active',
          EXPIRED: 'expired',
          DID_FAIL_TO_RENEW: 'past_due',
          GRACE_PERIOD: 'past_due',
        };
        const newStatus = statusMap[notification.data.notificationType] || subscription.status;
        const expiresAt = new Date(transaction.expiresDate);

        await SubscriptionModel.updateStatus(subscription.id, { status: newStatus, currentPeriodEnd: expiresAt });
        await SubscriptionModel.syncUserPlan(
          subscription.user_id,
          newStatus === 'expired' ? 'free' : subscription.plan,
          newStatus === 'expired' ? null : expiresAt
        );
      }

      return res.status(200).send('ok');
    } catch (err) {
      console.error('Erro processando notificação Apple:', err);
      return res.status(200).send('ok'); // Apple espera 200 mesmo em erro de negócio, pra não re-tentar indefinidamente
    }
  },

  // POST /api/payments/webhooks/google  (Pub/Sub push)
  async google(req, res) {
    try {
      const payload = GoogleIapProvider.parseRtdnPayload(req.body.message.data);
      const notification = payload.subscriptionNotification;
      if (notification) {
        const subscription = await SubscriptionModel.findByProviderSubscriptionId(notification.purchaseToken);
        if (subscription) {
          // 3 = renovada, 12 = expirada, 13 = revogada — ver docs RTDN do Google Play
          const statusMap = { 2: 'active', 3: 'active', 12: 'expired', 13: 'canceled' };
          const newStatus = statusMap[notification.notificationType] || subscription.status;
          await SubscriptionModel.updateStatus(subscription.id, { status: newStatus });
          if (newStatus === 'expired' || newStatus === 'canceled') {
            await SubscriptionModel.syncUserPlan(subscription.user_id, 'free', null);
          }
        }
      }
      return res.status(200).send('ok');
    } catch (err) {
      console.error('Erro processando RTDN Google:', err);
      return res.status(200).send('ok');
    }
  },

  // POST /api/payments/webhooks/mercado-pago  (PIX)
  async mercadoPago(req, res) {
    try {
      const paymentId = req.body.data?.id;
      if (!paymentId) return res.status(200).send('ok');

      const mpPayment = await PixProvider.getPayment(paymentId);
      const status = PixProvider.mapStatus(mpPayment.status);
      const updated = await PaymentModel.updateStatusByProviderId(String(paymentId), status);

      // Se era uma compra de pacote de Mega Coins ou item de loja, libera o item agora.
      if (updated && status === 'succeeded' && updated.metadata?.type === 'coin_pack') {
        await CoinsModel.applyTransaction({
          userId: updated.user_id,
          amount: updated.metadata.coinsAmount,
          reason: 'coin_pack_purchase',
          referenceId: updated.id,
        });
      }
      if (updated && status === 'succeeded' && updated.metadata?.type === 'store_product') {
        await StoreModel.recordPurchase({
          userId: updated.user_id,
          productId: updated.metadata.productId,
          paymentId: updated.id,
        });
      }

      return res.status(200).send('ok');
    } catch (err) {
      console.error('Erro processando webhook Mercado Pago:', err);
      return res.status(200).send('ok');
    }
  },
};

module.exports = WebhookController;
