const { query } = require('../config/db');

const NotificationModel = {
  async create({ userId, type, title, body, data }) {
    const { rows } = await query(
      `INSERT INTO notifications (user_id, type, title, body, data) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [userId, type, title, body, data || {}]
    );
    return rows[0];
  },

  async listForUser(userId, { unreadOnly = false, limit = 30, offset = 0 } = {}) {
    const where = unreadOnly ? 'AND read = FALSE' : '';
    const { rows } = await query(
      `SELECT * FROM notifications WHERE user_id = $1 ${where} ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
      [userId, limit, offset]
    );
    return rows;
  },

  async markRead(id, userId) {
    await query('UPDATE notifications SET read = TRUE WHERE id = $1 AND user_id = $2', [id, userId]);
  },

  async markAllRead(userId) {
    await query('UPDATE notifications SET read = TRUE WHERE user_id = $1 AND read = FALSE', [userId]);
  },

  async unreadCount(userId) {
    const { rows } = await query('SELECT COUNT(*) FROM notifications WHERE user_id = $1 AND read = FALSE', [userId]);
    return Number(rows[0].count);
  },

  // Broadcast usado pelo admin (ex: "Anúncio" do painel administrativo)
  async broadcastToAllUsers({ type, title, body, data }) {
    await query(
      `INSERT INTO notifications (user_id, type, title, body, data)
       SELECT id, $1, $2, $3, $4 FROM users WHERE is_banned = FALSE`,
      [type, title, body, data || {}]
    );
  },
};

const NotificationController = {
  // GET /api/notifications?unreadOnly=true  (autenticado)
  async list(req, res, next) {
    try {
      const notifications = await NotificationModel.listForUser(req.user.sub, {
        unreadOnly: req.query.unreadOnly === 'true',
      });
      return res.json({ notifications });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/notifications/unread-count  (autenticado)
  async unreadCount(req, res, next) {
    try {
      const count = await NotificationModel.unreadCount(req.user.sub);
      return res.json({ count });
    } catch (err) {
      next(err);
    }
  },

  // PATCH /api/notifications/:id/read  (autenticado)
  async markRead(req, res, next) {
    try {
      await NotificationModel.markRead(req.params.id, req.user.sub);
      return res.json({ message: 'Notificação marcada como lida.' });
    } catch (err) {
      next(err);
    }
  },

  // PATCH /api/notifications/read-all  (autenticado)
  async markAllRead(req, res, next) {
    try {
      await NotificationModel.markAllRead(req.user.sub);
      return res.json({ message: 'Todas as notificações marcadas como lidas.' });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = { NotificationModel, NotificationController };
