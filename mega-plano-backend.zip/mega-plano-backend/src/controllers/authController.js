const bcrypt = require('bcrypt');
const UserModel = require('../models/userModel');
const SessionModel = require('../models/sessionModel');
const VerificationTokenModel = require('../models/verificationTokenModel');
const { sendVerificationEmail, sendPasswordResetEmail } = require('../utils/email');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');
const { signTempTwoFactorToken } = require('../utils/twoFactorToken');

const SALT_ROUNDS = 12;

function refreshExpiryDate() {
  const days = parseInt((process.env.JWT_REFRESH_EXPIRES || '30d').replace('d', ''), 10);
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
}

const AuthController = {
  // POST /api/auth/register
  async register(req, res, next) {
    try {
      const { name, email, password } = req.body;

      const existing = await UserModel.findByEmail(email);
      if (existing) {
        return res.status(409).json({ error: 'E-mail já cadastrado.' });
      }

      const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
      const user = await UserModel.create({ name, email, passwordHash });

      const verificationToken = await VerificationTokenModel.create(user.id, 'email_verification');
      await sendVerificationEmail(user.email, user.name, verificationToken);

      return res.status(201).json({
        message: 'Conta criada. Verifique seu e-mail para ativar a conta.',
        user,
      });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/auth/login
  async login(req, res, next) {
    try {
      const { email, password } = req.body;

      const user = await UserModel.findByEmail(email);
      if (!user || !user.password_hash) {
        return res.status(401).json({ error: 'Credenciais inválidas.' });
      }

      if (user.is_banned) {
        return res.status(403).json({ error: 'Esta conta foi banida.' });
      }

      const validPassword = await bcrypt.compare(password, user.password_hash);
      if (!validPassword) {
        return res.status(401).json({ error: 'Credenciais inválidas.' });
      }

      if (!user.email_verified) {
        return res.status(403).json({ error: 'Confirme seu e-mail antes de entrar.', code: 'EMAIL_NOT_VERIFIED' });
      }

      // Se 2FA está ativo, não emite os tokens finais ainda: devolve um token
      // temporário de curta duração que só serve para completar o passo /2fa/login-verify.
      if (user.two_factor_enabled) {
        const tempToken = signTempTwoFactorToken(user);
        return res.json({ requiresTwoFactor: true, tempToken });
      }

      const accessToken = signAccessToken(user);
      const refreshToken = signRefreshToken(user);

      await SessionModel.create({
        userId: user.id,
        refreshToken,
        deviceInfo: req.headers['user-agent'] || 'desconhecido',
        ipAddress: req.ip,
        expiresAt: refreshExpiryDate(),
      });

      return res.json({
        accessToken,
        refreshToken,
        user: UserModel.toPublic(user),
      });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/auth/refresh
  async refresh(req, res, next) {
    try {
      const { refreshToken } = req.body;
      if (!refreshToken) return res.status(400).json({ error: 'refreshToken é obrigatório.' });

      const session = await SessionModel.findByToken(refreshToken);
      if (!session || new Date(session.expires_at) < new Date()) {
        return res.status(401).json({ error: 'Sessão expirada ou inválida.' });
      }

      const payload = verifyRefreshToken(refreshToken); // lança erro se assinatura inválida
      const user = await UserModel.findById(payload.sub);
      if (!user) return res.status(401).json({ error: 'Usuário não encontrado.' });

      const newAccessToken = signAccessToken(user);
      return res.json({ accessToken: newAccessToken });
    } catch (err) {
      return res.status(401).json({ error: 'Token de atualização inválido.' });
    }
  },

  // POST /api/auth/logout
  async logout(req, res, next) {
    try {
      const { refreshToken } = req.body;
      if (refreshToken) await SessionModel.revoke(refreshToken);
      return res.json({ message: 'Sessão encerrada.' });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/auth/verify-email?token=...
  async verifyEmail(req, res, next) {
    try {
      const { token } = req.query;
      const record = await VerificationTokenModel.findValid(token, 'email_verification');
      if (!record) return res.status(400).json({ error: 'Link de verificação inválido ou expirado.' });

      await UserModel.setEmailVerified(record.user_id);
      await VerificationTokenModel.markUsed(record.id);

      return res.json({ message: 'E-mail confirmado com sucesso! Você já pode entrar.' });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/auth/resend-verification  { email }
  async resendVerification(req, res, next) {
    try {
      const { email } = req.body;
      const user = await UserModel.findByEmail(email);
      // Resposta genérica sempre, mesmo se o e-mail não existir — evita
      // que alguém use esta rota pra descobrir quais e-mails estão cadastrados.
      if (user && !user.email_verified) {
        await VerificationTokenModel.invalidatePrevious(user.id, 'email_verification');
        const token = await VerificationTokenModel.create(user.id, 'email_verification');
        await sendVerificationEmail(user.email, user.name, token);
      }
      return res.json({ message: 'Se o e-mail existir e não estiver verificado, reenviamos o link.' });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/auth/forgot-password  { email }
  async forgotPassword(req, res, next) {
    try {
      const { email } = req.body;
      const user = await UserModel.findByEmail(email);
      if (user && user.password_hash) { // não faz sentido resetar senha de conta só-social
        await VerificationTokenModel.invalidatePrevious(user.id, 'password_reset');
        const token = await VerificationTokenModel.create(user.id, 'password_reset');
        await sendPasswordResetEmail(user.email, user.name, token);
      }
      return res.json({ message: 'Se o e-mail existir, enviamos instruções de redefinição.' });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/auth/reset-password  { token, newPassword }
  async resetPassword(req, res, next) {
    try {
      const { token, newPassword } = req.body;
      const record = await VerificationTokenModel.findValid(token, 'password_reset');
      if (!record) return res.status(400).json({ error: 'Link de redefinição inválido ou expirado.' });

      const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
      await UserModel.updatePassword(record.user_id, passwordHash);
      await VerificationTokenModel.markUsed(record.id);
      await SessionModel.revokeAllForUser(record.user_id); // força novo login em todos os dispositivos

      return res.json({ message: 'Senha redefinida com sucesso.' });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/auth/me
  async me(req, res, next) {
    try {
      const user = await UserModel.findById(req.user.sub);
      return res.json({ user: UserModel.toPublic(user) });
    } catch (err) {
      next(err);
    }
  },

  // PATCH /api/auth/me  { name?, bio?, avatarUrl? }
  async updateMe(req, res, next) {
    try {
      const { name, bio, avatarUrl } = req.body;
      const user = await UserModel.updateProfile(req.user.sub, { name, bio, avatarUrl });
      return res.json({ user });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = AuthController;
