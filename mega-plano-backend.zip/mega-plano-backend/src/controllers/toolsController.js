const crypto = require('crypto');
const qrcode = require('qrcode');
const CurrencyService = require('../services/currencyService');

const AMBIGUOUS_CHARS = 'il1Lo0O';

const ToolsController = {
  // GET /api/tools/password?length=16&symbols=true&numbers=true&uppercase=true&excludeAmbiguous=true
  // Stateless — não precisa de autenticação, mas fica atrás do rate limit padrão da API.
  generatePassword(req, res) {
    const length = Math.min(Math.max(Number(req.query.length) || 16, 6), 128);
    const useSymbols = req.query.symbols !== 'false';
    const useNumbers = req.query.numbers !== 'false';
    const useUppercase = req.query.uppercase !== 'false';
    const excludeAmbiguous = req.query.excludeAmbiguous === 'true';

    let charset = 'abcdefghijklmnopqrstuvwxyz';
    if (useUppercase) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (useNumbers) charset += '0123456789';
    if (useSymbols) charset += '!@#$%^&*()_-+=?';
    if (excludeAmbiguous) {
      charset = [...charset].filter((c) => !AMBIGUOUS_CHARS.includes(c)).join('');
    }

    // crypto.randomInt (não Math.random) — gerador de senha precisa ser
    // criptograficamente seguro, não só "parecer aleatório".
    const password = Array.from({ length }, () => charset[crypto.randomInt(charset.length)]).join('');
    return res.json({ password });
  },

  // POST /api/tools/qrcode  { text }  → retorna imagem em base64 (data URL)
  async generateQrCode(req, res, next) {
    try {
      const { text } = req.body;
      if (!text) return res.status(400).json({ error: 'Campo "text" é obrigatório.' });

      const dataUrl = await qrcode.toDataURL(text, { errorCorrectionLevel: 'M', margin: 2 });
      return res.json({ qrCodeDataUrl: dataUrl });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/tools/currency/convert?amount=100&from=BRL&to=USD
  async convertCurrency(req, res, next) {
    try {
      const { amount, from, to } = req.query;
      if (!amount || !from || !to) return res.status(400).json({ error: 'Parâmetros amount, from e to são obrigatórios.' });

      const result = await CurrencyService.convert(Number(amount), from.toUpperCase(), to.toUpperCase());
      return res.json({ amount: Number(amount), from, to, result });
    } catch (err) {
      if (err.message.includes('não suportada')) return res.status(400).json({ error: err.message });
      next(err);
    }
  },
};

module.exports = ToolsController;
