const { query } = require('../config/db');

const NoteModel = {
  async create(userId, { title, content }) {
    const { rows } = await query(
      `INSERT INTO notes (user_id, title, content) VALUES ($1,$2,$3) RETURNING *`,
      [userId, title || 'Sem título', content || '']
    );
    return rows[0];
  },

  async listForUser(userId) {
    const { rows } = await query(
      'SELECT * FROM notes WHERE user_id = $1 ORDER BY pinned DESC, updated_at DESC',
      [userId]
    );
    return rows;
  },

  async findById(id, userId) {
    const { rows } = await query('SELECT * FROM notes WHERE id = $1 AND user_id = $2', [id, userId]);
    return rows[0] || null;
  },

  async update(id, userId, { title, content, pinned }) {
    const { rows } = await query(
      `UPDATE notes SET title = COALESCE($3, title), content = COALESCE($4, content), pinned = COALESCE($5, pinned)
       WHERE id = $1 AND user_id = $2 RETURNING *`,
      [id, userId, title, content, pinned]
    );
    return rows[0] || null;
  },

  async delete(id, userId) {
    await query('DELETE FROM notes WHERE id = $1 AND user_id = $2', [id, userId]);
  },
};

const NoteController = {
  async list(req, res, next) {
    try {
      const notes = await NoteModel.listForUser(req.user.sub);
      return res.json({ notes });
    } catch (err) { next(err); }
  },

  async create(req, res, next) {
    try {
      const note = await NoteModel.create(req.user.sub, req.body);
      return res.status(201).json({ note });
    } catch (err) { next(err); }
  },

  async update(req, res, next) {
    try {
      const note = await NoteModel.update(req.params.id, req.user.sub, req.body);
      if (!note) return res.status(404).json({ error: 'Nota não encontrada.' });
      return res.json({ note });
    } catch (err) { next(err); }
  },

  async remove(req, res, next) {
    try {
      await NoteModel.delete(req.params.id, req.user.sub);
      return res.json({ message: 'Nota apagada.' });
    } catch (err) { next(err); }
  },
};

module.exports = { NoteModel, NoteController };
