const AdminUserModel = require('../models/adminUserModel');
const AuditLogModel = require('../models/auditLogModel');
const SessionModel = require('../models/sessionModel');

const AdminUserController = {
  // GET /api/admin/users?q=maria&role=user&banned=false
  async search(req, res, next) {
    try {
      const { q, role } = req.query;
      const banned = req.query.banned !== undefined ? req.query.banned === 'true' : undefined;
      const users = await AdminUserModel.search({
        q, role, banned,
        limit: Number(req.query.limit) || 30,
        offset: Number(req.query.offset) || 0,
      });
      return res.json({ users });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/admin/users/:id
  async getById(req, res, next) {
    try {
      const user = await AdminUserModel.findById(req.params.id);
      if (!user) return res.status(404).json({ error: 'Usuário não encontrado.' });
      return res.json({ user });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/admin/users/:id/ban   { reason? }
  async ban(req, res, next) {
    try {
      const target = await AdminUserModel.setBanned(req.params.id, true);
      if (!target) return res.status(404).json({ error: 'Usuário não encontrado.' });

      // Bane e já derruba todas as sessões ativas — sem isso o usuário
      // banido continuaria autenticado até o access token expirar sozinho.
      await SessionModel.revokeAllForUser(req.params.id);
      await AuditLogModel.record({
        userId: req.user.sub, action: 'user_banned',
        metadata: { targetUserId: req.params.id, reason: req.body.reason },
        ipAddress: req.ip,
      });

      return res.json({ message: 'Usuário banido.', user: target });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/admin/users/:id/unban
  async unban(req, res, next) {
    try {
      const target = await AdminUserModel.setBanned(req.params.id, false);
      if (!target) return res.status(404).json({ error: 'Usuário não encontrado.' });

      await AuditLogModel.record({
        userId: req.user.sub, action: 'user_unbanned',
        metadata: { targetUserId: req.params.id }, ipAddress: req.ip,
      });

      return res.json({ message: 'Usuário desbanido.', user: target });
    } catch (err) {
      next(err);
    }
  },

  // POST /api/admin/users/:id/role   { role }  — restrito a super_admin (ver rota)
  async changeRole(req, res, next) {
    try {
      const { role } = req.body;
      if (!['user', 'admin', 'super_admin'].includes(role)) {
        return res.status(400).json({ error: 'Role inválida.' });
      }
      if (req.params.id === req.user.sub) {
        return res.status(400).json({ error: 'Você não pode alterar sua própria role.' });
      }

      const target = await AdminUserModel.setRole(req.params.id, role);
      if (!target) return res.status(404).json({ error: 'Usuário não encontrado.' });

      await AuditLogModel.record({
        userId: req.user.sub, action: 'user_role_changed',
        metadata: { targetUserId: req.params.id, newRole: role }, ipAddress: req.ip,
      });

      return res.json({ message: 'Role atualizada.', user: target });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/admin/audit-logs?action=user_banned
  async listAuditLogs(req, res, next) {
    try {
      const logs = await AuditLogModel.list({
        action: req.query.action, userId: req.query.userId,
        limit: Number(req.query.limit) || 50, offset: Number(req.query.offset) || 0,
      });
      return res.json({ logs });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = AdminUserController;
