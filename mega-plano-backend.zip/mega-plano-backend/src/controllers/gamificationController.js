const AchievementService = require('../services/achievementService');
const UserModel = require('../models/userModel');

const GamificationController = {
  // GET /api/gamification/me  (autenticado) — resumo pra tela inicial (XP, nível, streak)
  async myStatus(req, res, next) {
    try {
      const user = await UserModel.findById(req.user.sub);
      return res.json({
        xp: user.xp,
        level: user.level,
        streakDays: user.streak_days,
        megaCoins: user.mega_coins,
      });
    } catch (err) {
      next(err);
    }
  },

  // GET /api/gamification/achievements  (autenticado) — todas + quais o usuário já tem
  async listAchievements(req, res, next) {
    try {
      const all = await AchievementService.listAll();
      const mine = await AchievementService.listForUser(req.user.sub);
      const earnedIds = new Set(mine.map((a) => a.id));

      const achievements = all.map((a) => ({ ...a, earned: earnedIds.has(a.id) }));
      return res.json({ achievements });
    } catch (err) {
      next(err);
    }
  },
};

module.exports = GamificationController;
