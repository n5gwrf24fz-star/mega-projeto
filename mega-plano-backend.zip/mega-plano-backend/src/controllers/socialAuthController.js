const { OAuth2Client } = require('google-auth-library');
const appleSignin = require('apple-signin-auth');
const { query } = require('../config/db');
const UserModel = require('../models/userModel');
const SessionModel = require('../models/sessionModel');
const { signAccessToken, signRefreshToken } = require('../utils/jwt');

const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

function refreshExpiryDate() {
  const days = parseInt((process.env.JWT_REFRESH_EXPIRES || '30d').replace('d', ''), 10);
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
}

async function issueSession(user, req) {
  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);
  await SessionModel.create({
    userId: user.id,
    refreshToken,
    deviceInfo: req.headers['user-agent'] || 'desconhecido',
    ipAddress: req.ip,
    expiresAt: refreshExpiryDate(),
  });
  return { accessToken, refreshToken };
}

// Encontra usuário pelo id do provedor social, criando a conta se for a
// primeira vez. E-mails de login social já chegam verificados pelo provedor.
async function findOrCreateSocialUser({ provider, providerId, email, name }) {
  const column = provider === 'google' ? 'google_id' : 'apple_id';

  const { rows: byProvider } = await query(`SELECT * FROM users WHERE ${column} = $1`, [providerId]);
  if (byProvider[0]) return byProvider[0];

  // Se já existe uma conta com esse e-mail (criada via senha), vincula o provedor a ela.
  const existingByEmail = await UserModel.findByEmail(email);
  if (existingByEmail) {
    await query(`UPDATE users SET ${column} = $1, email_verified = TRUE WHERE id = $2`, [
      providerId,
      existingByEmail.id,
    ]);
    return { ...existingByEmail, email_verified: true };
  }

  const { rows } = await query(
    `INSERT INTO users (name, email, ${column}, email_verified)
     VALUES ($1, $2, $3, TRUE) RETURNING *`,
    [name || email.split('@')[0], email, providerId]
  );
  return rows[0];
}

const SocialAuthController = {
  // POST /api/auth/google  { idToken }
  // idToken vem do SDK do Google no app Flutter (google_sign_in package).
  async google(req, res, next) {
    try {
      const { idToken } = req.body;
      const ticket = await googleClient.verifyIdToken({
        idToken,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      const payload = ticket.getPayload();

      if (!payload.email_verified) {
        return res.status(401).json({ error: 'E-mail Google não verificado.' });
      }

      const user = await findOrCreateSocialUser({
        provider: 'google',
        providerId: payload.sub,
        email: payload.email,
        name: payload.name,
      });

      if (user.is_banned) return res.status(403).json({ error: 'Esta conta foi banida.' });

      const tokens = await issueSession(user, req);
      return res.json({ ...tokens, user: UserModel.toPublic(user) });
    } catch (err) {
      return res.status(401).json({ error: 'Token do Google inválido.' });
    }
  },

  // POST /api/auth/apple  { identityToken, name? }
  // name só vem preenchido no primeiríssimo login (Apple só manda uma vez).
  async apple(req, res, next) {
    try {
      const { identityToken, name } = req.body;

      const payload = await appleSignin.verifyIdToken(identityToken, {
        audience: process.env.APPLE_CLIENT_ID,
        ignoreExpiration: false,
      });

      const user = await findOrCreateSocialUser({
        provider: 'apple',
        providerId: payload.sub,
        email: payload.email,
        name,
      });

      if (user.is_banned) return res.status(403).json({ error: 'Esta conta foi banida.' });

      const tokens = await issueSession(user, req);
      return res.json({ ...tokens, user: UserModel.toPublic(user) });
    } catch (err) {
      return res.status(401).json({ error: 'Token da Apple inválido.' });
    }
  },
};

module.exports = SocialAuthController;
