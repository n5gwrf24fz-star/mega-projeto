const { query } = require('../config/db');

const ChecklistModel = {
  async create(userId, title) {
    const { rows } = await query('INSERT INTO checklists (user_id, title) VALUES ($1,$2) RETURNING *', [userId, title]);
    return rows[0];
  },

  async listForUser(userId) {
    const { rows } = await query(
      `SELECT c.*,
         COALESCE(json_agg(ci ORDER BY ci.sort_order) FILTER (WHERE ci.id IS NOT NULL), '[]') AS items
       FROM checklists c
       LEFT JOIN checklist_items ci ON ci.checklist_id = c.id
       WHERE c.user_id = $1
       GROUP BY c.id ORDER BY c.created_at DESC`,
      [userId]
    );
    return rows;
  },

  async findById(id, userId) {
    const { rows } = await query('SELECT * FROM checklists WHERE id = $1 AND user_id = $2', [id, userId]);
    return rows[0] || null;
  },

  async delete(id, userId) {
    await query('DELETE FROM checklists WHERE id = $1 AND user_id = $2', [id, userId]);
  },

  async addItem(checklistId, text, sortOrder = 0) {
    const { rows } = await query(
      'INSERT INTO checklist_items (checklist_id, text, sort_order) VALUES ($1,$2,$3) RETURNING *',
      [checklistId, text, sortOrder]
    );
    return rows[0];
  },

  async toggleItem(itemId, checklistId) {
    const { rows } = await query(
      `UPDATE checklist_items SET completed = NOT completed
       WHERE id = $1 AND checklist_id = $2 RETURNING *`,
      [itemId, checklistId]
    );
    return rows[0] || null;
  },

  async deleteItem(itemId, checklistId) {
    await query('DELETE FROM checklist_items WHERE id = $1 AND checklist_id = $2', [itemId, checklistId]);
  },
};

const ChecklistController = {
  async list(req, res, next) {
    try {
      const checklists = await ChecklistModel.listForUser(req.user.sub);
      return res.json({ checklists });
    } catch (err) { next(err); }
  },

  async create(req, res, next) {
    try {
      const checklist = await ChecklistModel.create(req.user.sub, req.body.title || 'Nova lista');
      return res.status(201).json({ checklist });
    } catch (err) { next(err); }
  },

  async remove(req, res, next) {
    try {
      await ChecklistModel.delete(req.params.id, req.user.sub);
      return res.json({ message: 'Lista apagada.' });
    } catch (err) { next(err); }
  },

  // POST /api/tools/checklists/:id/items  { text }
  async addItem(req, res, next) {
    try {
      const checklist = await ChecklistModel.findById(req.params.id, req.user.sub);
      if (!checklist) return res.status(404).json({ error: 'Lista não encontrada.' });
      const item = await ChecklistModel.addItem(checklist.id, req.body.text);
      return res.status(201).json({ item });
    } catch (err) { next(err); }
  },

  // PATCH /api/tools/checklists/:id/items/:itemId/toggle
  async toggleItem(req, res, next) {
    try {
      const checklist = await ChecklistModel.findById(req.params.id, req.user.sub);
      if (!checklist) return res.status(404).json({ error: 'Lista não encontrada.' });
      const item = await ChecklistModel.toggleItem(req.params.itemId, checklist.id);
      if (!item) return res.status(404).json({ error: 'Item não encontrado.' });
      return res.json({ item });
    } catch (err) { next(err); }
  },

  async removeItem(req, res, next) {
    try {
      const checklist = await ChecklistModel.findById(req.params.id, req.user.sub);
      if (!checklist) return res.status(404).json({ error: 'Lista não encontrada.' });
      await ChecklistModel.deleteItem(req.params.itemId, checklist.id);
      return res.json({ message: 'Item removido.' });
    } catch (err) { next(err); }
  },
};

module.exports = { ChecklistModel, ChecklistController };
