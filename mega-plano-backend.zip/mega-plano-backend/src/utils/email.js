const transporter = require('../config/mailer');

const FROM = `"MEGA PLANO" <${process.env.SMTP_USER}>`;
const APP_URL = process.env.FRONTEND_URL || 'https://megaplano.app';

async function sendVerificationEmail(to, name, token) {
  const link = `${APP_URL}/verificar-email?token=${token}`;
  await transporter.sendMail({
    from: FROM,
    to,
    subject: 'Confirme seu e-mail — MEGA PLANO',
    html: `
      <div style="font-family: sans-serif; max-width: 480px; margin: auto;">
        <h2>Olá, ${name}! 👋</h2>
        <p>Falta pouco para começar a aprender o que quiser no MEGA PLANO.</p>
        <p><a href="${link}" style="background:#7c3aed;color:#fff;padding:12px 24px;
           border-radius:8px;text-decoration:none;">Confirmar meu e-mail</a></p>
        <p>Ou copie este link: ${link}</p>
        <p style="color:#888;font-size:12px;">Este link expira em 24 horas.</p>
      </div>`,
  });
}

async function sendPasswordResetEmail(to, name, token) {
  const link = `${APP_URL}/redefinir-senha?token=${token}`;
  await transporter.sendMail({
    from: FROM,
    to,
    subject: 'Redefinição de senha — MEGA PLANO',
    html: `
      <div style="font-family: sans-serif; max-width: 480px; margin: auto;">
        <h2>Olá, ${name}</h2>
        <p>Recebemos um pedido para redefinir sua senha.</p>
        <p><a href="${link}" style="background:#7c3aed;color:#fff;padding:12px 24px;
           border-radius:8px;text-decoration:none;">Redefinir senha</a></p>
        <p>Se você não pediu isso, pode ignorar este e-mail com segurança.</p>
        <p style="color:#888;font-size:12px;">Este link expira em 1 hora.</p>
      </div>`,
  });
}

module.exports = { sendVerificationEmail, sendPasswordResetEmail };
