const jwt = require('jsonwebtoken');
require('dotenv').config();

// Token de vida muito curta (5 min): prova que a senha já foi validada,
// mas ainda não autoriza acesso — só serve para completar o passo 2FA.
function signTempTwoFactorToken(user) {
  return jwt.sign(
    { sub: user.id, stage: '2fa_pending' },
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: '5m' }
  );
}

function verifyTempTwoFactorToken(token) {
  const payload = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
  if (payload.stage !== '2fa_pending') {
    throw new Error('Token inválido para esta etapa.');
  }
  return payload;
}

module.exports = { signTempTwoFactorToken, verifyTempTwoFactorToken };
