const UserModel = require('../models/userModel');
const AiUsageService = require('../services/aiUsageService');

// Aplica o limite diário de mensagens da Mega IA de acordo com o plano do
// usuário. Não bloqueia o recurso inteiro (free continua usando IA), só limita a quantidade.
async function aiUsageLimit(req, res, next) {
  try {
    const user = await UserModel.findById(req.user.sub);
    const allowed = await AiUsageService.canSendMessage(user.id, user.plan);

    if (!allowed) {
      const limit = AiUsageService.getDailyLimit(user.plan);
      return res.status(429).json({
        error: `Limite diário de ${limit} mensagens da Mega IA atingido.`,
        code: 'AI_DAILY_LIMIT_REACHED',
        upgradeHint: user.plan === 'free' ? 'Assine o PRO para um limite muito maior.' : undefined,
      });
    }

    // Incrementa aqui (antes da resposta da IA) para não deixar brecha de
    // requisições concorrentes furarem o limite.
    await AiUsageService.incrementUsage(user.id);
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = aiUsageLimit;
