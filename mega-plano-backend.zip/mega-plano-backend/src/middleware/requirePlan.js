const { planSatisfies } = require('../config/plans');
const UserModel = require('../models/userModel');

// Uso: router.get('/recurso-pro', requireAuth, requirePlan('pro'), controller)
// ultra automaticamente satisfaz requirePlan('pro') — ver planRank em config/plans.js
function requirePlan(minimumPlan) {
  return async (req, res, next) => {
    try {
      const user = await UserModel.findById(req.user.sub);
      if (!user) return res.status(401).json({ error: 'Usuário não encontrado.' });

      // Plano expirado é tratado como free mesmo que o campo ainda não tenha
      // sido sincronizado pelo webhook (defesa extra, não deveria acontecer).
      const effectivePlan = user.plan_expires_at && new Date(user.plan_expires_at) < new Date() ? 'free' : user.plan;

      if (!planSatisfies(effectivePlan, minimumPlan)) {
        return res.status(402).json({
          error: `Este recurso é exclusivo do plano ${minimumPlan.toUpperCase()} ou superior.`,
          code: 'PLAN_UPGRADE_REQUIRED',
          requiredPlan: minimumPlan,
        });
      }

      req.currentUser = user;
      next();
    } catch (err) {
      next(err);
    }
  };
}

module.exports = requirePlan;
