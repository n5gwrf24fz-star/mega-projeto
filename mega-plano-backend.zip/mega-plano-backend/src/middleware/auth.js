const { verifyAccessToken } = require('../utils/jwt');

// Exige um access token válido no header Authorization: Bearer <token>
function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token de acesso ausente.' });
  }

  try {
    const token = header.split(' ')[1];
    const payload = verifyAccessToken(token);
    req.user = payload; // { sub, role, email }
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token de acesso inválido ou expirado.' });
  }
}

// Restringe a rota a determinados roles. Ex: requireRole('admin', 'super_admin')
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Permissão insuficiente para esta ação.' });
    }
    next();
  };
}

module.exports = { requireAuth, requireRole };
