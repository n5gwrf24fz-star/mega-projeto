require('dotenv').config();
const app = require('./app');
const { connectRedis } = require('./config/redis');

const PORT = process.env.PORT || 3000;

async function start() {
  try {
    await connectRedis();
    app.listen(PORT, () => {
      console.log(`MEGA PLANO backend rodando na porta ${PORT} [${process.env.NODE_ENV}]`);
    });
  } catch (err) {
    console.error('Falha ao iniciar o servidor:', err);
    process.exit(1);
  }
}

start();
