const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const authRoutes = require('./routes/authRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const storeRoutes = require('./routes/storeRoutes');
const adminFinanceRoutes = require('./routes/adminFinanceRoutes');
const educationRoutes = require('./routes/educationRoutes');
const languageRoutes = require('./routes/languageRoutes');
const gameRoutes = require('./routes/gameRoutes');
const gamificationRoutes = require('./routes/gamificationRoutes');
const aiRoutes = require('./routes/aiRoutes');
const textGeneratorRoutes = require('./routes/textGeneratorRoutes');
const toolsRoutes = require('./routes/toolsRoutes');
const adminUserRoutes = require('./routes/adminUserRoutes');
const adminContentRoutes = require('./routes/adminContentRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// Segurança básica de headers HTTP
app.use(helmet());
app.use(cors());
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// IMPORTANTE: o webhook da Stripe precisa do corpo em formato RAW (bytes
// crus) para validar a assinatura HMAC — se passar pelo express.json()
// primeiro, o corpo já vem parseado e a verificação da assinatura falha.
// Por isso essa rota é registrada ANTES do express.json() global.
app.post('/api/payments/webhooks/stripe', express.raw({ type: 'application/json' }), require('./controllers/webhookController').stripe);

app.use(express.json({ limit: '2mb' }));

// Healthcheck (usado por load balancers / uptime monitors)
app.get('/health', (req, res) => res.json({ status: 'ok', service: 'mega-plano-backend' }));

// Rotas da API — cada módulo do MEGA PLANO ganhará seu próprio arquivo de rotas
// nas próximas fases (ex: /api/courses, /api/languages, /api/ai, /api/games...)
app.use('/api/auth', authRoutes);
app.use('/api/payments', paymentRoutes); // demais rotas de pagamento (a de webhook Stripe já foi montada acima)
app.use('/api/store', storeRoutes);
app.use('/api/admin/finance', adminFinanceRoutes);
app.use('/api/admin/content', adminContentRoutes);
app.use('/api/education', educationRoutes);
app.use('/api/languages', languageRoutes);
app.use('/api/games', gameRoutes);
app.use('/api/gamification', gamificationRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/text-generator', textGeneratorRoutes);
app.use('/api/tools', toolsRoutes);
app.use('/api/admin', adminUserRoutes);

// 404 para rotas não encontradas
app.use((req, res) => res.status(404).json({ error: 'Rota não encontrada.' }));

// Sempre por último: captura erros de qualquer rota acima
app.use(errorHandler);

module.exports = app;
