const { Pool } = require('pg');
require('dotenv').config();

// Pool de conexões: reutiliza conexões em vez de abrir uma nova a cada query,
// essencial para suportar milhares de usuários simultâneos.
const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  max: 20,                     // máx. de conexões simultâneas no pool
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  console.error('Erro inesperado no pool do PostgreSQL:', err);
});

/**
 * Executa uma query parametrizada (sempre use $1, $2... nunca concatene
 * strings — protege contra SQL Injection).
 */
async function query(text, params) {
  const start = Date.now();
  const result = await pool.query(text, params);
  if (process.env.NODE_ENV === 'development') {
    console.log('query executada', { text, duration: Date.now() - start, rows: result.rowCount });
  }
  return result;
}

/**
 * Para transações (ex: criar usuário + registrar log de auditoria juntos).
 */
async function getClient() {
  const client = await pool.connect();
  return client;
}

module.exports = { query, getClient, pool };
