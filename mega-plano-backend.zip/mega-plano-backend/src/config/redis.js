const { createClient } = require('redis');
require('dotenv').config();

const redisClient = createClient({ url: process.env.REDIS_URL });

redisClient.on('error', (err) => console.error('Erro no Redis:', err));

async function connectRedis() {
  if (!redisClient.isOpen) {
    await redisClient.connect();
    console.log('Redis conectado');
  }
}

module.exports = { redisClient, connectRedis };
