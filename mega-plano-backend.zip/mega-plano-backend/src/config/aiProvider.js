require('dotenv').config();

// Modelo usado varia por plano — ULTRA usa um modelo mais avançado (mais caro),
// respeitando o benefício "IA mais avançada" prometido no plano ULTRA.
// Mantido separado de config/plans.js para não misturar "regras de negócio
// do plano" com "detalhe de infraestrutura de qual modelo chamar".
const MODEL_BY_PLAN = {
  free: process.env.AI_MODEL_FREE || 'claude-haiku-4-5-20251001',
  pro: process.env.AI_MODEL_PRO || 'claude-sonnet-5',
  ultra: process.env.AI_MODEL_ULTRA || 'claude-opus-4-8',
};

const AI_API_URL = 'https://api.anthropic.com/v1/messages';
const AI_API_KEY = process.env.ANTHROPIC_API_KEY;
const AI_MAX_TOKENS = Number(process.env.AI_MAX_TOKENS || 1024);

module.exports = { MODEL_BY_PLAN, AI_API_URL, AI_API_KEY, AI_MAX_TOKENS };
