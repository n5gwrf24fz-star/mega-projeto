require('dotenv').config();

// Fonte única de verdade dos planos. Preços em BRL centavos. Mudar aqui
// reflete em checkout, exibição no app e nas checagens de acesso.
const PLANS = {
  free: {
    label: 'Gratuito',
    priceCents: 0,
    aiDailyLimit: Number(process.env.AI_FREE_DAILY_LIMIT || 20),
    features: ['materias_basicas', 'ferramentas_essenciais', 'cursos_gratuitos', 'idiomas_basicos', 'comunidade'],
  },
  pro: {
    label: 'MEGA PLANO PRO',
    priceCents: Number(process.env.PRICE_PRO_CENTS || 2990),
    stripePriceId: process.env.STRIPE_PRICE_ID_PRO,
    applePlanId: process.env.APPLE_PRODUCT_ID_PRO,       // ID do produto de assinatura na App Store Connect
    googlePlanId: process.env.GOOGLE_PRODUCT_ID_PRO,     // ID do produto no Google Play Console
    aiDailyLimit: Number(process.env.AI_PRO_DAILY_LIMIT || 500),
    trialDays: Number(process.env.TRIAL_DAYS_PRO || 7),
    features: [
      'todos_idiomas', 'todos_cursos', 'download_offline_ilimitado', 'ferramentas_exclusivas',
      'recursos_avancados_jogos', 'certificados_premium', 'temas_exclusivos', 'sem_anuncios', 'acesso_antecipado',
    ],
  },
  ultra: {
    label: 'MEGA PLANO ULTRA',
    priceCents: Number(process.env.PRICE_ULTRA_CENTS || 4990),
    stripePriceId: process.env.STRIPE_PRICE_ID_ULTRA,
    applePlanId: process.env.APPLE_PRODUCT_ID_ULTRA,
    googlePlanId: process.env.GOOGLE_PRODUCT_ID_ULTRA,
    aiDailyLimit: Number(process.env.AI_ULTRA_DAILY_LIMIT || 2000),
    trialDays: Number(process.env.TRIAL_DAYS_ULTRA || 7),
    features: [
      // tudo do PRO +
      'recursos_experimentais', 'ia_avancada', 'beta_features', 'mais_armazenamento_nuvem',
      'perfil_exclusivo', 'badge_exclusivo', 'suporte_prioritario',
    ],
  },
};

function planRank(plan) {
  return { free: 0, pro: 1, ultra: 2 }[plan] ?? 0;
}

// Verifica se `userPlan` dá direito a algo que exige `requiredPlan`
// (ultra também tem acesso a tudo que é do pro, por isso o "rank").
function planSatisfies(userPlan, requiredPlan) {
  return planRank(userPlan) >= planRank(requiredPlan);
}

module.exports = { PLANS, planRank, planSatisfies };
