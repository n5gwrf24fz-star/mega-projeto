const { query } = require('../config/db');

const LanguageModel = {
  async listAll() {
    const { rows } = await query('SELECT * FROM languages ORDER BY name');
    return rows;
  },

  async findById(id) {
    const { rows } = await query('SELECT * FROM languages WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async listUnits(languageId, type) {
    const params = [languageId];
    let extra = '';
    if (type) { params.push(type); extra = `AND type = $${params.length}`; }
    const { rows } = await query(
      `SELECT id, language_id, type, title, level, xp_reward, is_premium, sort_order
       FROM language_units WHERE language_id = $1 ${extra} ORDER BY sort_order`,
      params
    );
    return rows;
  },

  async findUnitById(id) {
    const { rows } = await query('SELECT * FROM language_units WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async listVocabulary(unitId) {
    const { rows } = await query('SELECT * FROM vocabulary_items WHERE unit_id = $1', [unitId]);
    return rows;
  },

  async getUserProgress(userId, languageId) {
    const { rows } = await query(
      'SELECT * FROM user_language_progress WHERE user_id = $1 AND language_id = $2',
      [userId, languageId]
    );
    return rows[0] || null;
  },

  async upsertUserProgress(userId, languageId, { xpDelta = 0, newLevel }) {
    const { rows } = await query(
      `INSERT INTO user_language_progress (user_id, language_id, xp_earned, current_level)
       VALUES ($1, $2, $3, COALESCE($4, 'A1'))
       ON CONFLICT (user_id, language_id) DO UPDATE SET
         xp_earned = user_language_progress.xp_earned + $3,
         current_level = COALESCE($4, user_language_progress.current_level)
       RETURNING *`,
      [userId, languageId, xpDelta, newLevel || null]
    );
    return rows[0];
  },

  async markUnitCompleted(userId, unitId) {
    await query(
      `INSERT INTO user_unit_progress (user_id, unit_id) VALUES ($1, $2)
       ON CONFLICT DO NOTHING`,
      [userId, unitId]
    );
  },

  async isUnitCompleted(userId, unitId) {
    const { rows } = await query(
      'SELECT 1 FROM user_unit_progress WHERE user_id = $1 AND unit_id = $2',
      [userId, unitId]
    );
    return !!rows[0];
  },

  async issueCertificate(userId, languageId, levelAchieved) {
    const { rows } = await query(
      `INSERT INTO language_certificates (user_id, language_id, level_achieved) VALUES ($1,$2,$3) RETURNING *`,
      [userId, languageId, levelAchieved]
    );
    return rows[0];
  },

  async listCertificates(userId) {
    const { rows } = await query(
      `SELECT c.*, l.name AS language_name FROM language_certificates c
       JOIN languages l ON l.id = c.language_id WHERE c.user_id = $1 ORDER BY c.issued_at DESC`,
      [userId]
    );
    return rows;
  },

  // --- Escrita (editor de conteúdo do admin) ---

  async createLanguage({ code, name, flagEmoji }) {
    const { rows } = await query(
      'INSERT INTO languages (code, name, flag_emoji) VALUES ($1,$2,$3) RETURNING *',
      [code, name, flagEmoji || null]
    );
    return rows[0];
  },

  async createUnit({ languageId, type, title, level, content, audioUrl, xpReward, isPremium, sortOrder }) {
    const { rows } = await query(
      `INSERT INTO language_units (language_id, type, title, level, content, audio_url, xp_reward, is_premium, sort_order)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [languageId, type, title, level || 'A1', content, audioUrl, xpReward ?? 10, isPremium ?? false, sortOrder ?? 0]
    );
    return rows[0];
  },

  async updateUnit(id, fields) {
    const { rows } = await query(
      `UPDATE language_units SET
         title = COALESCE($2, title), level = COALESCE($3, level), content = COALESCE($4, content),
         xp_reward = COALESCE($5, xp_reward), is_premium = COALESCE($6, is_premium), sort_order = COALESCE($7, sort_order)
       WHERE id = $1 RETURNING *`,
      [id, fields.title, fields.level, fields.content, fields.xpReward, fields.isPremium, fields.sortOrder]
    );
    return rows[0] || null;
  },

  async deleteUnit(id) {
    await query('DELETE FROM language_units WHERE id = $1', [id]);
  },

  async createVocabularyItem({ unitId, word, translation, exampleSentence, audioUrl, imageUrl }) {
    const { rows } = await query(
      `INSERT INTO vocabulary_items (unit_id, word, translation, example_sentence, audio_url, image_url)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [unitId, word, translation, exampleSentence, audioUrl, imageUrl]
    );
    return rows[0];
  },

  async deleteVocabularyItem(id) {
    await query('DELETE FROM vocabulary_items WHERE id = $1', [id]);
  },
};

const FlashcardModel = {
  async listDueForReview(userId, deckId) {
    const { rows } = await query(
      `SELECT f.*, COALESCE(ufp.box_level, 1) AS box_level
       FROM flashcards f
       LEFT JOIN user_flashcard_progress ufp ON ufp.flashcard_id = f.id AND ufp.user_id = $2
       WHERE f.deck_id = $1 AND (ufp.next_review_at IS NULL OR ufp.next_review_at <= now())`,
      [deckId, userId]
    );
    return rows;
  },

  // Algoritmo tipo Leitner simplificado: acertou sobe uma caixa (revisa mais
  // tarde), errou volta pra caixa 1 (revisa de novo logo).
  async recordReview(userId, flashcardId, correct) {
    const { rows: current } = await query(
      'SELECT box_level FROM user_flashcard_progress WHERE user_id = $1 AND flashcard_id = $2',
      [userId, flashcardId]
    );
    const currentBox = current[0]?.box_level ?? 1;
    const newBox = correct ? Math.min(currentBox + 1, 5) : 1;
    const intervalDays = [0, 1, 3, 7, 14, 30][newBox]; // caixa 5 revisa em 30 dias, caixa 1 revisa amanhã

    const { rows } = await query(
      `INSERT INTO user_flashcard_progress (user_id, flashcard_id, box_level, next_review_at)
       VALUES ($1, $2, $3, now() + ($4 || ' days')::interval)
       ON CONFLICT (user_id, flashcard_id) DO UPDATE SET
         box_level = $3, next_review_at = now() + ($4 || ' days')::interval
       RETURNING *`,
      [userId, flashcardId, newBox, intervalDays]
    );
    return rows[0];
  },
};

module.exports = { LanguageModel, FlashcardModel };
