const { query } = require('../config/db');

const UserModel = {
  async findByEmail(email) {
    const { rows } = await query('SELECT * FROM users WHERE email = $1', [email]);
    return rows[0] || null;
  },

  async findById(id) {
    const { rows } = await query('SELECT * FROM users WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async create({ name, email, passwordHash }) {
    const { rows } = await query(
      `INSERT INTO users (name, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, name, email, role, xp, level, email_verified, created_at`,
      [name, email, passwordHash]
    );
    return rows[0];
  },

  async setEmailVerified(userId) {
    await query('UPDATE users SET email_verified = TRUE WHERE id = $1', [userId]);
  },

  async updatePassword(userId, passwordHash) {
    await query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, userId]);
  },

  async updateProfile(userId, { name, bio, avatarUrl }) {
    const { rows } = await query(
      `UPDATE users SET
         name = COALESCE($2, name), bio = COALESCE($3, bio), avatar_url = COALESCE($4, avatar_url)
       WHERE id = $1
       RETURNING id, name, email, role, bio, avatar_url, xp, level, mega_coins, plan`,
      [userId, name, bio, avatarUrl]
    );
    return rows[0];
  },

  // Retorna apenas campos seguros para expor ao cliente (nunca o hash da senha).
  toPublic(user) {
    if (!user) return null;
    const { password_hash, two_factor_secret, ...publicUser } = user;
    return publicUser;
  },
};

module.exports = UserModel;
