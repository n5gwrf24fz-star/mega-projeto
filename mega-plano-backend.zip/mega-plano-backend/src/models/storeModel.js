const { query } = require('../config/db');

const StoreModel = {
  async listActiveProducts({ category } = {}) {
    const params = [];
    let where = 'WHERE active = TRUE';
    if (category) { params.push(category); where += ` AND category = $${params.length}`; }
    const { rows } = await query(`SELECT * FROM store_products ${where} ORDER BY category, name`, params);
    return rows;
  },

  // Usado só pelo admin — inclui produtos desativados, que a listagem
  // pública (usada no app) esconde de propósito.
  async listAllForAdmin() {
    const { rows } = await query('SELECT * FROM store_products ORDER BY category, name');
    return rows;
  },

  async findById(id) {
    const { rows } = await query('SELECT * FROM store_products WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async create(product) {
    const { rows } = await query(
      `INSERT INTO store_products (sku, category, name, description, image_url, currency, price_cents, price_coins, requires_plan)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [product.sku, product.category, product.name, product.description, product.imageUrl,
       product.currency, product.priceCents || null, product.priceCoins || null, product.requiresPlan || null]
    );
    return rows[0];
  },

  async setActive(id, active) {
    await query('UPDATE store_products SET active = $1 WHERE id = $2', [active, id]);
  },

  async recordPurchase({ userId, productId, paymentId, coinsSpent }) {
    const { rows } = await query(
      `INSERT INTO store_purchases (user_id, product_id, payment_id, coins_spent)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [userId, productId, paymentId || null, coinsSpent || null]
    );
    return rows[0];
  },

  async userAlreadyOwns(userId, productId) {
    const { rows } = await query(
      'SELECT 1 FROM store_purchases WHERE user_id = $1 AND product_id = $2',
      [userId, productId]
    );
    return !!rows[0];
  },

  async listUserPurchases(userId) {
    const { rows } = await query(
      `SELECT sp.*, p.name, p.category, p.image_url
       FROM store_purchases sp JOIN store_products p ON p.id = sp.product_id
       WHERE sp.user_id = $1 ORDER BY sp.created_at DESC`,
      [userId]
    );
    return rows;
  },
};

module.exports = StoreModel;
