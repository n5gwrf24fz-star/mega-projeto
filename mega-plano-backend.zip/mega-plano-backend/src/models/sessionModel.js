const { query } = require('../config/db');

const SessionModel = {
  async create({ userId, refreshToken, deviceInfo, ipAddress, expiresAt }) {
    const { rows } = await query(
      `INSERT INTO sessions (user_id, refresh_token, device_info, ip_address, expires_at)
       VALUES ($1, $2, $3, $4, $5) RETURNING id`,
      [userId, refreshToken, deviceInfo, ipAddress, expiresAt]
    );
    return rows[0];
  },

  async findByToken(refreshToken) {
    const { rows } = await query(
      'SELECT * FROM sessions WHERE refresh_token = $1 AND revoked = FALSE',
      [refreshToken]
    );
    return rows[0] || null;
  },

  async revoke(refreshToken) {
    await query('UPDATE sessions SET revoked = TRUE WHERE refresh_token = $1', [refreshToken]);
  },

  async revokeAllForUser(userId) {
    await query('UPDATE sessions SET revoked = TRUE WHERE user_id = $1', [userId]);
  },
};

module.exports = SessionModel;
