const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

const TOKEN_TTL_HOURS = { email_verification: 24, password_reset: 1 };

const VerificationTokenModel = {
  async create(userId, type) {
    const token = uuidv4();
    const expiresAt = new Date(Date.now() + TOKEN_TTL_HOURS[type] * 60 * 60 * 1000);

    await query(
      `INSERT INTO verification_tokens (user_id, token, type, expires_at)
       VALUES ($1, $2, $3, $4)`,
      [userId, token, type, expiresAt]
    );
    return token;
  },

  async findValid(token, type) {
    const { rows } = await query(
      `SELECT * FROM verification_tokens
       WHERE token = $1 AND type = $2 AND used = FALSE AND expires_at > now()`,
      [token, type]
    );
    return rows[0] || null;
  },

  async markUsed(id) {
    await query('UPDATE verification_tokens SET used = TRUE WHERE id = $1', [id]);
  },

  // Invalida tokens antigos do mesmo tipo antes de emitir um novo (evita acúmulo).
  async invalidatePrevious(userId, type) {
    await query(
      'UPDATE verification_tokens SET used = TRUE WHERE user_id = $1 AND type = $2 AND used = FALSE',
      [userId, type]
    );
  },
};

module.exports = VerificationTokenModel;
