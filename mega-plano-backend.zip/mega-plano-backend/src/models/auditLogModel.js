const { query } = require('../config/db');

const AuditLogModel = {
  async record({ userId, action, metadata, ipAddress }) {
    await query(
      'INSERT INTO audit_logs (user_id, action, metadata, ip_address) VALUES ($1,$2,$3,$4)',
      [userId, action, metadata || {}, ipAddress || null]
    );
  },

  async list({ action, userId, limit = 50, offset = 0 } = {}) {
    const conditions = [];
    const params = [];
    if (action) { params.push(action); conditions.push(`al.action = $${params.length}`); }
    if (userId) { params.push(userId); conditions.push(`al.user_id = $${params.length}`); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    params.push(limit, offset);

    const { rows } = await query(
      `SELECT al.*, u.name AS user_name, u.email AS user_email
       FROM audit_logs al LEFT JOIN users u ON u.id = al.user_id
       ${where}
       ORDER BY al.created_at DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    return rows;
  },
};

module.exports = AuditLogModel;
