const { query } = require('../config/db');

const AiConversationModel = {
  async create(userId, context) {
    const { rows } = await query(
      `INSERT INTO ai_conversations (user_id, context) VALUES ($1, $2) RETURNING *`,
      [userId, context || 'general']
    );
    return rows[0];
  },

  async findById(id, userId) {
    const { rows } = await query('SELECT * FROM ai_conversations WHERE id = $1 AND user_id = $2', [id, userId]);
    return rows[0] || null;
  },

  async listForUser(userId) {
    const { rows } = await query(
      'SELECT * FROM ai_conversations WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 50',
      [userId]
    );
    return rows;
  },

  async touch(id) {
    await query('UPDATE ai_conversations SET updated_at = now() WHERE id = $1', [id]);
  },

  async renameIfDefault(id, firstUserMessage) {
    // Usa as primeiras palavras da primeira mensagem como título, só se
    // ainda estiver com o título padrão "Nova conversa".
    const title = firstUserMessage.slice(0, 60).trim();
    await query(
      `UPDATE ai_conversations SET title = $1 WHERE id = $2 AND title = 'Nova conversa'`,
      [title, id]
    );
  },

  async delete(id, userId) {
    await query('DELETE FROM ai_conversations WHERE id = $1 AND user_id = $2', [id, userId]);
  },
};

const AiMessageModel = {
  async add(conversationId, role, content) {
    const { rows } = await query(
      `INSERT INTO ai_messages (conversation_id, role, content) VALUES ($1,$2,$3) RETURNING *`,
      [conversationId, role, content]
    );
    return rows[0];
  },

  async listForConversation(conversationId) {
    const { rows } = await query(
      'SELECT * FROM ai_messages WHERE conversation_id = $1 ORDER BY created_at',
      [conversationId]
    );
    return rows;
  },
};

module.exports = { AiConversationModel, AiMessageModel };
