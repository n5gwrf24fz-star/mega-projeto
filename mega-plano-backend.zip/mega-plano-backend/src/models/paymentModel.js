const { query } = require('../config/db');

const PaymentModel = {
  async create({ userId, subscriptionId, provider, providerPaymentId, status, amountCents, currency = 'BRL', description, couponCode, metadata }) {
    const { rows } = await query(
      `INSERT INTO payments (user_id, subscription_id, provider, provider_payment_id, status, amount_cents, currency, description, coupon_code, metadata)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [userId, subscriptionId, provider, providerPaymentId, status, amountCents, currency, description, couponCode, metadata || {}]
    );
    return rows[0];
  },

  async updateStatusByProviderId(providerPaymentId, status) {
    const { rows } = await query(
      'UPDATE payments SET status = $1 WHERE provider_payment_id = $2 RETURNING *',
      [status, providerPaymentId]
    );
    return rows[0];
  },

  async findByProviderId(providerPaymentId) {
    const { rows } = await query('SELECT * FROM payments WHERE provider_payment_id = $1', [providerPaymentId]);
    return rows[0] || null;
  },

  async listForUser(userId, { limit = 20, offset = 0 } = {}) {
    const { rows } = await query(
      'SELECT * FROM payments WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3',
      [userId, limit, offset]
    );
    return rows;
  },

  // Receita total e por período — base dos relatórios financeiros do admin.
  async revenueSummary({ from, to }) {
    const { rows } = await query(
      `SELECT
         COALESCE(SUM(amount_cents) FILTER (WHERE status = 'succeeded'), 0) AS total_cents,
         COUNT(*) FILTER (WHERE status = 'succeeded') AS successful_count,
         COUNT(*) FILTER (WHERE status = 'failed') AS failed_count,
         COUNT(*) FILTER (WHERE status = 'refunded') AS refunded_count
       FROM payments
       WHERE created_at BETWEEN $1 AND $2`,
      [from, to]
    );
    return rows[0];
  },

  async revenueByPlan({ from, to }) {
    const { rows } = await query(
      `SELECT s.plan, COALESCE(SUM(p.amount_cents), 0) AS total_cents, COUNT(*) AS payment_count
       FROM payments p
       LEFT JOIN subscriptions s ON s.id = p.subscription_id
       WHERE p.status = 'succeeded' AND p.created_at BETWEEN $1 AND $2
       GROUP BY s.plan`,
      [from, to]
    );
    return rows;
  },
};

module.exports = PaymentModel;
