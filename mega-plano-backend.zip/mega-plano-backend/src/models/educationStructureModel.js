const { query } = require('../config/db');

const GradeLevelModel = {
  async listByStage(stage) {
    const params = [];
    let where = '';
    if (stage) { params.push(stage); where = 'WHERE stage = $1'; }
    const { rows } = await query(`SELECT * FROM grade_levels ${where} ORDER BY sort_order`, params);
    return rows;
  },

  async findById(id) {
    const { rows } = await query('SELECT * FROM grade_levels WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async create({ stage, name, sortOrder }) {
    const { rows } = await query(
      'INSERT INTO grade_levels (stage, name, sort_order) VALUES ($1,$2,$3) RETURNING *',
      [stage, name, sortOrder || 0]
    );
    return rows[0];
  },

  async update(id, { name, sortOrder }) {
    const { rows } = await query(
      'UPDATE grade_levels SET name = COALESCE($2, name), sort_order = COALESCE($3, sort_order) WHERE id = $1 RETURNING *',
      [id, name, sortOrder]
    );
    return rows[0] || null;
  },

  async delete(id) {
    await query('DELETE FROM grade_levels WHERE id = $1', [id]);
  },
};

const SubjectModel = {
  async listByGradeLevel(gradeLevelId) {
    const { rows } = await query(
      'SELECT * FROM subjects WHERE grade_level_id = $1 ORDER BY sort_order',
      [gradeLevelId]
    );
    return rows;
  },

  async findById(id) {
    const { rows } = await query('SELECT * FROM subjects WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async create({ gradeLevelId, name, icon, sortOrder }) {
    const { rows } = await query(
      'INSERT INTO subjects (grade_level_id, name, icon, sort_order) VALUES ($1,$2,$3,$4) RETURNING *',
      [gradeLevelId, name, icon || null, sortOrder || 0]
    );
    return rows[0];
  },

  async update(id, { name, icon, sortOrder }) {
    const { rows } = await query(
      `UPDATE subjects SET name = COALESCE($2, name), icon = COALESCE($3, icon), sort_order = COALESCE($4, sort_order)
       WHERE id = $1 RETURNING *`,
      [id, name, icon, sortOrder]
    );
    return rows[0] || null;
  },

  async delete(id) {
    await query('DELETE FROM subjects WHERE id = $1', [id]);
  },
};

module.exports = { GradeLevelModel, SubjectModel };
