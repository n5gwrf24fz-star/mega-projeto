const { query, getClient } = require('../config/db');

const CouponModel = {
  async findActiveByCode(code) {
    const { rows } = await query(
      `SELECT * FROM coupons
       WHERE code = $1 AND active = TRUE AND (expires_at IS NULL OR expires_at > now())`,
      [code.toUpperCase()]
    );
    return rows[0] || null;
  },

  async create({ code, type, value, maxRedemptions, expiresAt, createdBy }) {
    const { rows } = await query(
      `INSERT INTO coupons (code, type, value, max_redemptions, expires_at, created_by)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [code.toUpperCase(), type, value, maxRedemptions || null, expiresAt || null, createdBy]
    );
    return rows[0];
  },

  async listAll({ activeOnly = false } = {}) {
    const where = activeOnly ? 'WHERE active = TRUE' : '';
    const { rows } = await query(`SELECT * FROM coupons ${where} ORDER BY created_at DESC`);
    return rows;
  },

  async deactivate(id) {
    await query('UPDATE coupons SET active = FALSE WHERE id = $1', [id]);
  },

  // Resgate atômico: garante que o mesmo cupom não seja usado 2x pelo mesmo
  // usuário mesmo sob requisições concorrentes, e respeita o limite global.
  async redeem(coupon, userId) {
    const client = await getClient();
    try {
      await client.query('BEGIN');

      const { rows: locked } = await client.query('SELECT * FROM coupons WHERE id = $1 FOR UPDATE', [coupon.id]);
      const current = locked[0];

      if (!current.active) throw new Error('Cupom inativo.');
      if (current.max_redemptions !== null && current.times_redeemed >= current.max_redemptions) {
        throw new Error('Cupom esgotado.');
      }

      const { rows: already } = await client.query(
        'SELECT 1 FROM coupon_redemptions WHERE coupon_id = $1 AND user_id = $2',
        [coupon.id, userId]
      );
      if (already[0]) throw new Error('Você já usou este cupom.');

      await client.query('INSERT INTO coupon_redemptions (coupon_id, user_id) VALUES ($1, $2)', [coupon.id, userId]);
      await client.query('UPDATE coupons SET times_redeemed = times_redeemed + 1 WHERE id = $1', [coupon.id]);

      await client.query('COMMIT');
      return current;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },
};

module.exports = CouponModel;
