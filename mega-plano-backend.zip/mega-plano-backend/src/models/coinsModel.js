const { getClient, query } = require('../config/db');

const CoinsModel = {
  // Crédito/débito atômico: nunca deixa o saldo cache (users.mega_coins)
  // dessincronizar do ledger, mesmo com requisições concorrentes.
  async applyTransaction({ userId, amount, reason, referenceId }) {
    const client = await getClient();
    try {
      await client.query('BEGIN');

      const { rows: userRows } = await client.query('SELECT mega_coins FROM users WHERE id = $1 FOR UPDATE', [userId]);
      const currentBalance = userRows[0]?.mega_coins ?? 0;

      if (amount < 0 && currentBalance + amount < 0) {
        throw new Error('Saldo de Mega Coins insuficiente.');
      }

      await client.query('UPDATE users SET mega_coins = mega_coins + $1 WHERE id = $2', [amount, userId]);
      const { rows } = await client.query(
        `INSERT INTO mega_coins_transactions (user_id, amount, reason, reference_id)
         VALUES ($1,$2,$3,$4) RETURNING *`,
        [userId, amount, reason, referenceId || null]
      );

      await client.query('COMMIT');
      return { transaction: rows[0], newBalance: currentBalance + amount };
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },

  async getBalance(userId) {
    const { rows } = await query('SELECT mega_coins FROM users WHERE id = $1', [userId]);
    return rows[0]?.mega_coins ?? 0;
  },

  async listHistory(userId, { limit = 30, offset = 0 } = {}) {
    const { rows } = await query(
      'SELECT * FROM mega_coins_transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3',
      [userId, limit, offset]
    );
    return rows;
  },
};

module.exports = CoinsModel;
