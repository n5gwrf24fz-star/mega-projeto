const { query } = require('../config/db');

const AdminUserModel = {
  // Busca por nome ou e-mail (ILIKE) + filtro opcional por role/status —
  // usado tanto pela tela de moderação quanto pra achar o ID de alguém
  // rapidamente (ex: pra conceder Mega Coins sem digitar UUID de cabeça).
  async search({ q, role, banned, limit = 30, offset = 0 }) {
    const conditions = [];
    const params = [];

    if (q) {
      params.push(`%${q}%`);
      conditions.push(`(name ILIKE $${params.length} OR email ILIKE $${params.length})`);
    }
    if (role) { params.push(role); conditions.push(`role = $${params.length}`); }
    if (banned !== undefined) { params.push(banned); conditions.push(`is_banned = $${params.length}`); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    params.push(limit, offset);

    const { rows } = await query(
      `SELECT id, name, email, role, plan, xp, level, is_banned, email_verified, created_at
       FROM users ${where}
       ORDER BY created_at DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    return rows;
  },

  async findById(id) {
    const { rows } = await query(
      `SELECT id, name, email, role, plan, plan_expires_at, xp, level, streak_days, mega_coins,
              is_banned, email_verified, two_factor_enabled, created_at
       FROM users WHERE id = $1`,
      [id]
    );
    return rows[0] || null;
  },

  async setBanned(id, banned) {
    const { rows } = await query('UPDATE users SET is_banned = $1 WHERE id = $2 RETURNING id, is_banned', [banned, id]);
    return rows[0] || null;
  },

  // Trocar role é uma ação sensível — só super_admin pode chamar isso
  // (reforçado na rota, não só aqui, mas vale deixar o comentário perto da query também).
  async setRole(id, role) {
    const { rows } = await query('UPDATE users SET role = $1 WHERE id = $2 RETURNING id, role', [role, id]);
    return rows[0] || null;
  },

  async countByRole() {
    const { rows } = await query('SELECT role, COUNT(*) AS count FROM users GROUP BY role');
    return rows;
  },
};

module.exports = AdminUserModel;
