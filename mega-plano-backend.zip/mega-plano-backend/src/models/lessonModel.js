const { query } = require('../config/db');

const LessonModel = {
  async listBySubject(subjectId) {
    const { rows } = await query(
      'SELECT id, subject_id, title, content_type, xp_reward, is_premium, sort_order FROM lessons WHERE subject_id = $1 ORDER BY sort_order',
      [subjectId]
    );
    return rows;
  },

  // Retorna a aula com o campo `content` só quando o usuário tem acesso —
  // controller decide isso antes de chamar findFullById.
  async findFullById(id) {
    const { rows } = await query('SELECT * FROM lessons WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async listExercises(lessonId) {
    const { rows } = await query(
      'SELECT id, lesson_id, type, question, options, xp_reward, sort_order FROM exercises WHERE lesson_id = $1 ORDER BY sort_order',
      [lessonId]
      // Nunca retorna correct_answer/explanation aqui — só depois de responder (ver checkAnswer).
    );
    return rows;
  },

  async findExerciseById(id) {
    const { rows } = await query('SELECT * FROM exercises WHERE id = $1', [id]);
    return rows[0] || null;
  },

  // --- Escrita (editor de conteúdo do admin) ---

  async create({ subjectId, title, contentType, content, videoUrl, xpReward, isPremium, sortOrder }) {
    const { rows } = await query(
      `INSERT INTO lessons (subject_id, title, content_type, content, video_url, xp_reward, is_premium, sort_order)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [subjectId, title, contentType || 'explanation', content, videoUrl, xpReward ?? 10, isPremium ?? false, sortOrder ?? 0]
    );
    return rows[0];
  },

  async update(id, fields) {
    const { rows } = await query(
      `UPDATE lessons SET
         title = COALESCE($2, title), content = COALESCE($3, content), video_url = COALESCE($4, video_url),
         xp_reward = COALESCE($5, xp_reward), is_premium = COALESCE($6, is_premium), sort_order = COALESCE($7, sort_order)
       WHERE id = $1 RETURNING *`,
      [id, fields.title, fields.content, fields.videoUrl, fields.xpReward, fields.isPremium, fields.sortOrder]
    );
    return rows[0] || null;
  },

  async delete(id) {
    await query('DELETE FROM lessons WHERE id = $1', [id]);
  },

  async createExercise({ lessonId, type, question, options, correctAnswer, explanation, xpReward, sortOrder }) {
    const { rows } = await query(
      `INSERT INTO exercises (lesson_id, type, question, options, correct_answer, explanation, xp_reward, sort_order)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [lessonId, type || 'multiple_choice', question, JSON.stringify(options || []), correctAnswer, explanation, xpReward ?? 5, sortOrder ?? 0]
    );
    return rows[0];
  },

  async updateExercise(id, fields) {
    const { rows } = await query(
      `UPDATE exercises SET
         question = COALESCE($2, question), options = COALESCE($3, options), correct_answer = COALESCE($4, correct_answer),
         explanation = COALESCE($5, explanation), xp_reward = COALESCE($6, xp_reward), sort_order = COALESCE($7, sort_order)
       WHERE id = $1 RETURNING *`,
      [id, fields.question, fields.options ? JSON.stringify(fields.options) : null, fields.correctAnswer, fields.explanation, fields.xpReward, fields.sortOrder]
    );
    return rows[0] || null;
  },

  async deleteExercise(id) {
    await query('DELETE FROM exercises WHERE id = $1', [id]);
  },
};

const ProgressModel = {
  async markLessonCompleted(userId, lessonId) {
    const { rows } = await query(
      `INSERT INTO user_lesson_progress (user_id, lesson_id, completed, completed_at)
       VALUES ($1, $2, TRUE, now())
       ON CONFLICT (user_id, lesson_id) DO UPDATE SET completed = TRUE, completed_at = now()
       RETURNING *`,
      [userId, lessonId]
    );
    return rows[0];
  },

  async isLessonCompleted(userId, lessonId) {
    const { rows } = await query(
      'SELECT 1 FROM user_lesson_progress WHERE user_id = $1 AND lesson_id = $2 AND completed = TRUE',
      [userId, lessonId]
    );
    return !!rows[0];
  },

  async recordExerciseAttempt({ userId, exerciseId, answerGiven, isCorrect }) {
    const { rows } = await query(
      `INSERT INTO user_exercise_attempts (user_id, exercise_id, answer_given, is_correct)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [userId, exerciseId, answerGiven, isCorrect]
    );
    return rows[0];
  },

  async subjectProgressSummary(userId, subjectId) {
    const { rows } = await query(
      `SELECT COUNT(*) FILTER (WHERE ulp.completed) AS completed_count, COUNT(l.id) AS total_count
       FROM lessons l
       LEFT JOIN user_lesson_progress ulp ON ulp.lesson_id = l.id AND ulp.user_id = $2
       WHERE l.subject_id = $1`,
      [subjectId, userId]
    );
    return rows[0];
  },
};

module.exports = { LessonModel, ProgressModel };
