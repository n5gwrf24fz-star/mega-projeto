const { query } = require('../config/db');

const SubscriptionModel = {
  async create({ userId, plan, status, provider, providerSubscriptionId, trialEndsAt, currentPeriodStart, currentPeriodEnd }) {
    const { rows } = await query(
      `INSERT INTO subscriptions
        (user_id, plan, status, provider, provider_subscription_id, trial_ends_at, current_period_start, current_period_end)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [userId, plan, status, provider, providerSubscriptionId, trialEndsAt, currentPeriodStart, currentPeriodEnd]
    );
    return rows[0];
  },

  async findByProviderSubscriptionId(providerSubscriptionId) {
    const { rows } = await query('SELECT * FROM subscriptions WHERE provider_subscription_id = $1', [providerSubscriptionId]);
    return rows[0] || null;
  },

  async findActiveByUser(userId) {
    const { rows } = await query(
      `SELECT * FROM subscriptions WHERE user_id = $1 AND status IN ('trialing','active','past_due')
       ORDER BY created_at DESC LIMIT 1`,
      [userId]
    );
    return rows[0] || null;
  },

  async updateStatus(id, fields) {
    const { rows } = await query(
      `UPDATE subscriptions SET
        status = COALESCE($2, status),
        current_period_start = COALESCE($3, current_period_start),
        current_period_end = COALESCE($4, current_period_end),
        cancel_at_period_end = COALESCE($5, cancel_at_period_end),
        canceled_at = COALESCE($6, canceled_at)
       WHERE id = $1 RETURNING *`,
      [id, fields.status, fields.currentPeriodStart, fields.currentPeriodEnd, fields.cancelAtPeriodEnd, fields.canceledAt]
    );
    return rows[0];
  },

  // Aplica o plano no usuário (campo denormalizado usado nas checagens de acesso).
  async syncUserPlan(userId, plan, expiresAt) {
    await query('UPDATE users SET plan = $1, plan_expires_at = $2 WHERE id = $3', [plan, expiresAt, userId]);
  },

  async listForAdmin({ status, plan, limit = 50, offset = 0 }) {
    const conditions = [];
    const params = [];
    if (status) { params.push(status); conditions.push(`s.status = $${params.length}`); }
    if (plan) { params.push(plan); conditions.push(`s.plan = $${params.length}`); }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    params.push(limit, offset);
    const { rows } = await query(
      `SELECT s.*, u.name AS user_name, u.email AS user_email
       FROM subscriptions s JOIN users u ON u.id = s.user_id
       ${where}
       ORDER BY s.created_at DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    return rows;
  },
};

module.exports = SubscriptionModel;
