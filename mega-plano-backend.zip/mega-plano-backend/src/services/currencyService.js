const axios = require('axios');
const { redisClient } = require('../config/redis');

const CACHE_KEY = 'currency_rates:BRL';
const CACHE_TTL_SECONDS = 60 * 60; // 1h — câmbio não precisa ser em tempo real pra este caso de uso

const CurrencyService = {
  async getRates() {
    const cached = await redisClient.get(CACHE_KEY);
    if (cached) return JSON.parse(cached);

    // API pública gratuita, sem necessidade de chave — trocar por um provedor
    // pago (ex: exchangerate-api.com com API key) se o volume justificar.
    const { data } = await axios.get('https://open.er-api.com/v6/latest/BRL');
    if (data.result !== 'success') throw new Error('Não foi possível obter as taxas de câmbio.');

    await redisClient.set(CACHE_KEY, JSON.stringify(data.rates), { EX: CACHE_TTL_SECONDS });
    return data.rates;
  },

  async convert(amount, from, to) {
    const rates = await this.getRates(); // taxas relativas ao BRL
    if (!rates[from] || !rates[to]) throw new Error('Moeda não suportada.');

    const amountInBrl = from === 'BRL' ? amount : amount / rates[from];
    const converted = to === 'BRL' ? amountInBrl : amountInBrl * rates[to];
    return Math.round(converted * 100) / 100;
  },
};

module.exports = CurrencyService;
