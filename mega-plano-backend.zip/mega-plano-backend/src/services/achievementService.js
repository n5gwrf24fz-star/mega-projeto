const { query } = require('../config/db');
const XpService = require('./xpService');
const CoinsModel = require('../models/coinsModel');

const AchievementService = {
  async findByCode(code) {
    const { rows } = await query('SELECT * FROM achievements WHERE code = $1', [code]);
    return rows[0] || null;
  },

  async userHasAchievement(userId, achievementId) {
    const { rows } = await query(
      'SELECT 1 FROM user_achievements WHERE user_id = $1 AND achievement_id = $2',
      [userId, achievementId]
    );
    return !!rows[0];
  },

  // Concede uma conquista se o usuário ainda não a tem, aplicando as
  // recompensas de XP/coins associadas. Chamado pelos outros módulos sempre
  // que uma condição é atingida (ex: 1ª aula concluída, streak de 7 dias).
  async grantIfNew(userId, code) {
    const achievement = await this.findByCode(code);
    if (!achievement) return null;

    const already = await this.userHasAchievement(userId, achievement.id);
    if (already) return null;

    await query('INSERT INTO user_achievements (user_id, achievement_id) VALUES ($1, $2)', [userId, achievement.id]);

    if (achievement.xp_reward > 0) {
      await XpService.grant({ userId, amount: achievement.xp_reward, reason: 'admin_grant', referenceId: achievement.id });
    }
    if (achievement.coins_reward > 0) {
      await CoinsModel.applyTransaction({ userId, amount: achievement.coins_reward, reason: 'achievement', referenceId: achievement.id });
    }

    return achievement;
  },

  async listForUser(userId) {
    const { rows } = await query(
      `SELECT a.*, ua.earned_at FROM achievements a
       JOIN user_achievements ua ON ua.achievement_id = a.id
       WHERE ua.user_id = $1 ORDER BY ua.earned_at DESC`,
      [userId]
    );
    return rows;
  },

  async listAll() {
    const { rows } = await query('SELECT * FROM achievements ORDER BY name');
    return rows;
  },
};

module.exports = AchievementService;
