const axios = require('axios');
const { MODEL_BY_PLAN, AI_API_URL, AI_API_KEY, AI_MAX_TOKENS } = require('../config/aiProvider');

// System prompts por contexto — ajusta o comportamento da Mega IA conforme
// a tela de onde o usuário está falando com ela (spec pede: explicar
// conteúdos, tirar dúvidas de estudo/lição de casa, ajudar a escrever,
// ajudar a programar, traduzir, resumir, dar ideias).
const SYSTEM_PROMPTS = {
  general: 'Você é a Mega IA, assistente do app educacional MEGA PLANO. Responda em português do Brasil, de forma clara, amigável e didática.',
  study_helper: 'Você é a Mega IA atuando como tutora de estudos. Explique conceitos passo a passo, com exemplos simples, adaptando a linguagem ao nível escolar do aluno quando informado. Responda em português do Brasil.',
  homework: 'Você é a Mega IA ajudando com lição de casa. Guie o raciocínio do aluno em vez de só dar a resposta pronta — incentive-o a pensar, mas confirme se a resposta final dele está correta quando ele responder. Responda em português do Brasil.',
  writing: 'Você é a Mega IA como assistente de escrita. Ajude a melhorar clareza, gramática e estrutura do texto do usuário, respeitando o tom que ele pedir. Responda em português do Brasil.',
  code: 'Você é a Mega IA como assistente de programação. Explique conceitos de forma didática e revise/sugira código quando pedido, com boas práticas. Responda em português do Brasil.',
};

async function callAnthropic({ model, system, messages }) {
  if (!AI_API_KEY) {
    throw new Error('ANTHROPIC_API_KEY não configurada no ambiente.');
  }

  const { data } = await axios.post(
    AI_API_URL,
    { model, max_tokens: AI_MAX_TOKENS, system, messages },
    {
      headers: {
        'x-api-key': AI_API_KEY,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
    }
  );

  const textBlock = data.content.find((block) => block.type === 'text');
  return textBlock ? textBlock.text : '';
}

const AiService = {
  buildSystemPrompt(context) {
    return SYSTEM_PROMPTS[context] || SYSTEM_PROMPTS.general;
  },

  /**
   * Envia o histórico de uma conversa pra IA e retorna a resposta em texto.
   * `history` é um array [{ role: 'user'|'assistant', content: '...' }, ...]
   */
  async sendMessage({ history, context, plan }) {
    const model = MODEL_BY_PLAN[plan] || MODEL_BY_PLAN.free;
    return callAnthropic({
      model,
      system: this.buildSystemPrompt(context),
      messages: history.map((m) => ({ role: m.role, content: m.content })),
    });
  },

  // Chamada avulsa de "uma pergunta, uma resposta" — usada pelo Gerador de
  // Textos, que não precisa manter histórico de conversa.
  async complete({ prompt, plan, systemPrompt }) {
    const model = MODEL_BY_PLAN[plan] || MODEL_BY_PLAN.free;
    return callAnthropic({
      model,
      system: systemPrompt || SYSTEM_PROMPTS.general,
      messages: [{ role: 'user', content: prompt }],
    });
  },
};

module.exports = AiService;
