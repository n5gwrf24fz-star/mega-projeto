const { redisClient } = require('../config/redis');
const { PLANS } = require('../config/plans');

function todayKey(userId) {
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  return `ai_usage:${userId}:${today}`;
}

const AiUsageService = {
  // Usa Redis (não Postgres) porque é um contador de alta frequência com TTL
  // natural de 1 dia — não precisa virar linha permanente no banco.
  async getUsageToday(userId) {
    const value = await redisClient.get(todayKey(userId));
    return value ? parseInt(value, 10) : 0;
  },

  getDailyLimit(plan) {
    return PLANS[plan]?.aiDailyLimit ?? PLANS.free.aiDailyLimit;
  },

  async canSendMessage(userId, plan) {
    const used = await this.getUsageToday(userId);
    return used < this.getDailyLimit(plan);
  },

  async incrementUsage(userId) {
    const key = todayKey(userId);
    const newCount = await redisClient.incr(key);
    if (newCount === 1) {
      await redisClient.expire(key, 60 * 60 * 26); // expira ~2h depois da virada do dia (folga de fuso)
    }
    return newCount;
  },
};

module.exports = AiUsageService;
