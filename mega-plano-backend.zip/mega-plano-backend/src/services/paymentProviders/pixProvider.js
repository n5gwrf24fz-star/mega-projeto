const axios = require('axios');

// PIX não é suportado nativamente pela Stripe no Brasil, por isso usamos o
// Mercado Pago para esse método especificamente. PIX aqui é usado para
// compras avulsas (pacotes de Mega Coins, itens da loja) — assinaturas
// recorrentes continuam via Stripe/IAP, já que PIX não tem cobrança recorrente nativa.
const mpClient = axios.create({
  baseURL: 'https://api.mercadopago.com',
  headers: { Authorization: `Bearer ${process.env.MERCADO_PAGO_ACCESS_TOKEN}` },
});

const PixProvider = {
  async createPixPayment({ amountCents, description, payerEmail, externalReference }) {
    const { data } = await mpClient.post('/v1/payments', {
      transaction_amount: amountCents / 100,
      description,
      payment_method_id: 'pix',
      payer: { email: payerEmail },
      external_reference: externalReference, // usamos pra linkar de volta ao nosso payments.id
      notification_url: `${process.env.API_URL}/api/payments/webhooks/mercado-pago`,
    });

    return {
      providerPaymentId: String(data.id),
      qrCode: data.point_of_interaction?.transaction_data?.qr_code,
      qrCodeBase64: data.point_of_interaction?.transaction_data?.qr_code_base64,
      status: data.status, // 'pending' | 'approved' | 'rejected'
      expiresAt: data.date_of_expiration,
    };
  },

  async getPayment(providerPaymentId) {
    const { data } = await mpClient.get(`/v1/payments/${providerPaymentId}`);
    return data;
  },

  mapStatus(mpStatus) {
    if (mpStatus === 'approved') return 'succeeded';
    if (mpStatus === 'rejected' || mpStatus === 'cancelled') return 'failed';
    return 'pending';
  },
};

module.exports = PixProvider;
