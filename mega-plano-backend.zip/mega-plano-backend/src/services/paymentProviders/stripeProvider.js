const stripe = require('../../config/stripe');
const { PLANS } = require('../../config/plans');

// Stripe é usado para cartão de crédito/débito e também renderiza Apple Pay /
// Google Pay automaticamente no Checkout quando acessado de Safari/Chrome
// mobile — não precisa de integração separada para esses dois no fluxo web.
const StripeProvider = {
  async ensureCustomer(user) {
    if (user.stripe_customer_id) return user.stripe_customer_id;

    const customer = await stripe.customers.create({
      email: user.email,
      name: user.name,
      metadata: { megaPlanoUserId: user.id },
    });

    const { query } = require('../../config/db');
    await query('UPDATE users SET stripe_customer_id = $1 WHERE id = $2', [customer.id, user.id]);
    return customer.id;
  },

  // Cria uma sessão de Checkout hospedada pela Stripe (mais simples e segura
  // do que construir formulário de cartão próprio — reduz escopo de PCI-DSS).
  async createCheckoutSession({ user, plan, successUrl, cancelUrl, couponStripeId }) {
    const planConfig = PLANS[plan];
    if (!planConfig?.stripePriceId) throw new Error(`Plano ${plan} não tem price configurado na Stripe.`);

    const customerId = await this.ensureCustomer(user);

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: customerId,
      line_items: [{ price: planConfig.stripePriceId, quantity: 1 }],
      subscription_data: planConfig.trialDays ? { trial_period_days: planConfig.trialDays } : undefined,
      discounts: couponStripeId ? [{ coupon: couponStripeId }] : undefined,
      payment_method_types: ['card'], // Apple Pay / Google Pay aparecem automaticamente se elegível
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: { megaPlanoUserId: user.id, plan },
    });

    return session;
  },

  async cancelAtPeriodEnd(providerSubscriptionId) {
    return stripe.subscriptions.update(providerSubscriptionId, { cancel_at_period_end: true });
  },

  async cancelImmediately(providerSubscriptionId) {
    return stripe.subscriptions.cancel(providerSubscriptionId);
  },

  // Valida a assinatura do webhook — nunca confie em payload de webhook sem isso,
  // qualquer um poderia forjar um POST dizendo "pagamento aprovado".
  constructWebhookEvent(rawBody, signature) {
    return stripe.webhooks.constructEvent(rawBody, signature, process.env.STRIPE_WEBHOOK_SECRET);
  },
};

module.exports = StripeProvider;
