const jwt = require('jsonwebtoken');

// Assinaturas compradas dentro do app iOS usam o StoreKit nativo (obrigatório
// pela política da App Store — não dá pra cobrar assinatura por fora nesse caso).
// O app manda pra cá o "signed transaction" (JWS) recebido do StoreKit 2, e o
// backend valida e sincroniza o estado da assinatura.
const AppleIapProvider = {
  /**
   * Decodifica o JWS de uma transação assinada pela Apple (StoreKit 2).
   *
   * IMPORTANTE — produção: aqui deve entrar a validação completa da cadeia de
   * certificados x5c contra a Apple Root CA (ou, mais simples, chamar a
   * App Store Server API da Apple para verificar a transação em vez de
   * validar localmente). Deixado como TODO explícito porque depende de
   * credenciais (Key ID, Issuer ID, .p8) que só existem depois de configurado
   * no App Store Connect.
   */
  decodeSignedTransaction(signedTransactionInfo) {
    // decode() sem verify: suficiente para extrair os campos e seguir o fluxo
    // de desenvolvimento, mas NÃO deve ser considerado prova de autenticidade
    // até o TODO acima ser implementado.
    const decoded = jwt.decode(signedTransactionInfo);
    if (!decoded) throw new Error('Não foi possível decodificar a transação da Apple.');
    return decoded;
    // decoded contém: originalTransactionId, productId, purchaseDate,
    // expiresDate, transactionId, etc.
  },

  mapProductIdToPlan(productId) {
    const { PLANS } = require('../../config/plans');
    if (productId === PLANS.pro.applePlanId) return 'pro';
    if (productId === PLANS.ultra.applePlanId) return 'ultra';
    return null;
  },

  /**
   * App Store Server Notifications V2: a Apple envia um webhook (também um
   * JWS) sempre que uma assinatura renova, cancela, entra em grace period etc.
   * Mesma ressalva de validação de assinatura do método acima.
   */
  decodeServerNotification(signedPayload) {
    const decoded = jwt.decode(signedPayload);
    if (!decoded) throw new Error('Notificação da Apple inválida.');
    // decoded.data.signedTransactionInfo contém a transação relacionada ao evento
    return decoded;
  },
};

module.exports = AppleIapProvider;
