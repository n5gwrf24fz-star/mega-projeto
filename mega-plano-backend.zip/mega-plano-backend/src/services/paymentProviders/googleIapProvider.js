const { google } = require('googleapis');

// Assinaturas compradas no Android usam o Google Play Billing. O app manda
// pra cá o purchaseToken retornado pela Billing Library, e o backend verifica
// diretamente com a Google Play Developer API (mais seguro que confiar no
// que o cliente diz — o token prova que a compra é real).
let androidPublisherClient = null;

async function getClient() {
  if (androidPublisherClient) return androidPublisherClient;

  const auth = new google.auth.GoogleAuth({
    // Caminho para o JSON da service account do Google Cloud com permissão
    // no Play Console (Configurações > Acesso à API).
    keyFile: process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_KEY_FILE,
    scopes: ['https://www.googleapis.com/auth/androidpublisher'],
  });

  androidPublisherClient = google.androidpublisher({ version: 'v3', auth });
  return androidPublisherClient;
}

const GoogleIapProvider = {
  async verifySubscription({ packageName, subscriptionId, purchaseToken }) {
    const client = await getClient();
    const { data } = await client.purchases.subscriptions.get({
      packageName,
      subscriptionId,
      token: purchaseToken,
    });
    return data;
    // data.expiryTimeMillis, data.paymentState (0=pendente,1=recebido,2=trial,3=pending deferred), etc.
  },

  mapProductIdToPlan(subscriptionId) {
    const { PLANS } = require('../../config/plans');
    if (subscriptionId === PLANS.pro.googlePlanId) return 'pro';
    if (subscriptionId === PLANS.ultra.googlePlanId) return 'ultra';
    return null;
  },

  // Real-Time Developer Notifications chegam via Pub/Sub — o payload já vem
  // decodificado em base64 JSON pelo controller antes de chegar aqui.
  parseRtdnPayload(base64Data) {
    const json = Buffer.from(base64Data, 'base64').toString('utf8');
    return JSON.parse(json);
  },
};

module.exports = GoogleIapProvider;
