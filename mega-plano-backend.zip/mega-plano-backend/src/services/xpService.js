const { getClient } = require('../config/db');

// Curva de nível simples: cada nível exige 100xp a mais que o anterior
// (nível 1: 0-99, nível 2: 100-299, nível 3: 300-599...). Ajustável aqui
// sem tocar em nenhum outro lugar do código.
function levelForXp(totalXp) {
  let level = 1;
  let threshold = 100;
  let remaining = totalXp;
  while (remaining >= threshold) {
    remaining -= threshold;
    level += 1;
    threshold += 100;
  }
  return level;
}

const XpService = {
  // Concede XP de forma atômica e recalcula o nível do usuário. Também
  // atualiza a sequência de estudos (streak) baseada na última atividade.
  async grant({ userId, amount, reason, referenceId }) {
    const client = await getClient();
    try {
      await client.query('BEGIN');

      const { rows: userRows } = await client.query(
        'SELECT xp, level, streak_days, last_activity_date FROM users WHERE id = $1 FOR UPDATE',
        [userId]
      );
      const user = userRows[0];
      const newXp = user.xp + amount;
      const newLevel = levelForXp(newXp);

      const today = new Date().toISOString().slice(0, 10);
      const lastActivity = user.last_activity_date ? user.last_activity_date.toISOString().slice(0, 10) : null;
      let newStreak = user.streak_days;

      if (lastActivity !== today) {
        const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
        newStreak = lastActivity === yesterday ? user.streak_days + 1 : 1; // quebrou a sequência → reinicia em 1
      }

      await client.query(
        'UPDATE users SET xp = $1, level = $2, streak_days = $3, last_activity_date = $4 WHERE id = $5',
        [newXp, newLevel, newStreak, today, userId]
      );
      await client.query(
        `INSERT INTO xp_events (user_id, amount, reason, reference_id) VALUES ($1,$2,$3,$4)`,
        [userId, amount, reason, referenceId || null]
      );

      await client.query('COMMIT');
      return { xp: newXp, level: newLevel, leveledUp: newLevel > user.level, streakDays: newStreak };
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },

  levelForXp,
};

module.exports = XpService;
