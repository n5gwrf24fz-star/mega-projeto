-- MEGA PLANO — Schema de Gamificação e Utilidades Transversais (Fase 4)

-- Ledger de XP (igual ao de Mega Coins: nunca se apaga, saldo em users.xp é cache)
CREATE TYPE xp_reason AS ENUM (
    'lesson_completed', 'exercise_correct', 'mock_exam_completed', 'language_unit_completed',
    'daily_login', 'challenge_completed', 'helped_community', 'admin_grant'
);

CREATE TABLE xp_events (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount      INTEGER NOT NULL,
    reason      xp_reason NOT NULL,
    reference_id UUID,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_xp_events_user ON xp_events(user_id);

-- Controla a sequência de dias estudando (streak) sem precisar varrer todo o histórico
ALTER TABLE users ADD COLUMN last_activity_date DATE;

-- Conquistas/medalhas
CREATE TABLE achievements (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code        VARCHAR(60) UNIQUE NOT NULL,   -- 'first_lesson', 'streak_7', 'polyglot_3_languages'...
    name        VARCHAR(120) NOT NULL,
    description TEXT,
    icon_url    TEXT,
    xp_reward   INTEGER NOT NULL DEFAULT 0,
    coins_reward INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE user_achievements (
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    achievement_id UUID NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
    earned_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, achievement_id)
);

-- Favoritos genéricos: um único mecanismo cobre aulas, ferramentas, idiomas,
-- jogos, artigos e conversas de IA (spec pede favoritar todos esses tipos).
CREATE TYPE favorite_content_type AS ENUM ('lesson', 'tool', 'language_unit', 'game_guide', 'article', 'ai_chat', 'store_product');

CREATE TABLE favorites (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content_type favorite_content_type NOT NULL,
    content_id   UUID NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (user_id, content_type, content_id)
);

CREATE INDEX idx_favorites_user ON favorites(user_id, content_type);

-- Notificações
CREATE TYPE notification_type AS ENUM ('study_reminder', 'update', 'admin_announcement', 'friend_request', 'challenge_invite', 'achievement_earned', 'payment');

CREATE TABLE notifications (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        notification_type NOT NULL,
    title       VARCHAR(150) NOT NULL,
    body        TEXT,
    data        JSONB,             -- payload extra (ex: id da aula, id do amigo)
    read        BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_notifications_user_unread ON notifications(user_id, read);
