-- MEGA PLANO — Schema de Educação (Fase 4)

CREATE TYPE education_stage AS ENUM ('elementary_1', 'elementary_2', 'high_school');
-- elementary_1 = Ensino Fundamental I (1º-5º ano)
-- elementary_2 = Ensino Fundamental II (6º-9º ano)
-- high_school   = Ensino Médio (1º-3º ano)

CREATE TABLE grade_levels (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    stage       education_stage NOT NULL,
    name        VARCHAR(50) NOT NULL,     -- ex: "5º ano"
    sort_order  INTEGER NOT NULL          -- ordena 1º ano antes de 2º ano, etc.
);

CREATE TABLE subjects (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    grade_level_id UUID NOT NULL REFERENCES grade_levels(id) ON DELETE CASCADE,
    name           VARCHAR(80) NOT NULL,   -- Matemática, Português, História...
    icon           VARCHAR(50),
    sort_order     INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_subjects_grade_level ON subjects(grade_level_id);

CREATE TYPE lesson_content_type AS ENUM ('summary', 'explanation', 'video', 'interactive');

CREATE TABLE lessons (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject_id   UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    title        VARCHAR(150) NOT NULL,
    content_type lesson_content_type NOT NULL DEFAULT 'explanation',
    content      TEXT,                 -- markdown
    video_url    TEXT,
    xp_reward    INTEGER NOT NULL DEFAULT 10,
    is_premium   BOOLEAN NOT NULL DEFAULT FALSE,  -- só assinantes PRO/ULTRA (ver requiresPlan)
    sort_order   INTEGER NOT NULL DEFAULT 0,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_lessons_subject ON lessons(subject_id);

CREATE TYPE exercise_type AS ENUM ('multiple_choice', 'true_false', 'fill_blank', 'open_text');

CREATE TABLE exercises (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lesson_id      UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    type           exercise_type NOT NULL DEFAULT 'multiple_choice',
    question       TEXT NOT NULL,
    options        JSONB,             -- ex: ["A) ...", "B) ...", "C) ...", "D) ..."]
    correct_answer TEXT NOT NULL,
    explanation    TEXT,              -- exibido depois de responder
    xp_reward      INTEGER NOT NULL DEFAULT 5,
    sort_order     INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_exercises_lesson ON exercises(lesson_id);

-- Simulados: agrupam exercícios de várias aulas de uma matéria
CREATE TABLE mock_exams (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject_id  UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    title       VARCHAR(150) NOT NULL,
    description TEXT,
    time_limit_minutes INTEGER,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE mock_exam_exercises (
    mock_exam_id UUID NOT NULL REFERENCES mock_exams(id) ON DELETE CASCADE,
    exercise_id  UUID NOT NULL REFERENCES exercises(id) ON DELETE CASCADE,
    sort_order   INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (mock_exam_id, exercise_id)
);

-- Progresso do usuário nas aulas
CREATE TABLE user_lesson_progress (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lesson_id    UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    completed    BOOLEAN NOT NULL DEFAULT FALSE,
    completed_at TIMESTAMPTZ,
    UNIQUE (user_id, lesson_id)
);

CREATE INDEX idx_user_lesson_progress_user ON user_lesson_progress(user_id);

-- Tentativas de exercícios (permite refazer e acompanhar histórico de acertos)
CREATE TABLE user_exercise_attempts (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exercise_id  UUID NOT NULL REFERENCES exercises(id) ON DELETE CASCADE,
    answer_given TEXT NOT NULL,
    is_correct   BOOLEAN NOT NULL,
    attempted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_user_exercise_attempts_user ON user_exercise_attempts(user_id);
CREATE INDEX idx_user_exercise_attempts_exercise ON user_exercise_attempts(exercise_id);
