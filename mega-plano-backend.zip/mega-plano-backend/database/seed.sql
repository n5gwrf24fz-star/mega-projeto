-- MEGA PLANO — Seed de dados de exemplo
-- Roda por último, depois de todos os arquivos schema_*.sql
-- Uso: psql -U postgres -d mega_plano -f database/seed.sql

BEGIN;

-- ============ EDUCAÇÃO ============

WITH gl AS (
  INSERT INTO grade_levels (stage, name, sort_order) VALUES
    ('elementary_1', '1º ano', 1),
    ('elementary_1', '2º ano', 2),
    ('elementary_1', '3º ano', 3),
    ('elementary_1', '4º ano', 4),
    ('elementary_1', '5º ano', 5),
    ('elementary_2', '6º ano', 1),
    ('elementary_2', '7º ano', 2),
    ('elementary_2', '8º ano', 3),
    ('elementary_2', '9º ano', 4),
    ('high_school', '1º ano', 1),
    ('high_school', '2º ano', 2),
    ('high_school', '3º ano', 3)
  RETURNING id, name
),
subj AS (
  INSERT INTO subjects (grade_level_id, name, icon, sort_order)
  SELECT gl.id, s.name, s.icon, s.sort_order
  FROM gl
  CROSS JOIN (VALUES
    ('Matemática', 'matematica', 1),
    ('Português', 'portugues', 2),
    ('Ciências', 'ciencias', 3),
    ('História', 'historia', 4),
    ('Geografia', 'geografia', 5)
  ) AS s(name, icon, sort_order)
  WHERE gl.name = '5º ano'
  RETURNING id, name
),
mat AS (SELECT id FROM subj WHERE name = 'Matemática'),
lessons_ins AS (
  INSERT INTO lessons (subject_id, title, content_type, content, xp_reward, is_premium, sort_order)
  SELECT mat.id, l.title, 'explanation', l.content, l.xp_reward, l.is_premium, l.sort_order
  FROM mat
  CROSS JOIN (VALUES
    ('Introdução às frações', 'Uma fração representa uma parte de um todo. Por exemplo, 1/2 significa uma parte de um total de duas partes iguais. O número de cima (numerador) diz quantas partes você tem, e o número de baixo (denominador) diz em quantas partes o todo foi dividido.', 10, FALSE, 1),
    ('Somando frações', 'Para somar frações com o mesmo denominador, basta somar os numeradores e manter o denominador. Exemplo: 1/4 + 2/4 = 3/4. Quando os denominadores são diferentes, primeiro é preciso encontrar um denominador comum.', 15, FALSE, 2),
    ('Frações equivalentes (PRO)', 'Duas frações são equivalentes quando representam a mesma quantidade, mesmo com números diferentes. Por exemplo, 1/2 é equivalente a 2/4 e a 3/6. Este conteúdo aprofundado é exclusivo para assinantes.', 20, TRUE, 3)
  ) AS l(title, content, xp_reward, is_premium, sort_order)
  RETURNING id, title
)
INSERT INTO exercises (lesson_id, type, question, options, correct_answer, explanation, xp_reward, sort_order)
SELECT lessons_ins.id, 'multiple_choice', e.question, e.options::jsonb, e.correct_answer, e.explanation, e.xp_reward, 1
FROM lessons_ins
CROSS JOIN (VALUES
  ('Introdução às frações', 'Em 3/4, qual é o denominador?', '["3", "4", "7", "1"]', '4', 'O denominador é o número de baixo — nesse caso, 4.', 5),
  ('Somando frações', 'Quanto é 1/5 + 2/5?', '["3/10", "3/5", "1/5", "2/10"]', '3/5', 'Com denominadores iguais, soma-se só os numeradores: 1+2=3, mantendo o denominador 5.', 5)
) AS e(lesson_title, question, options, correct_answer, explanation, xp_reward)
WHERE lessons_ins.title = e.lesson_title;

-- ============ IDIOMAS ============

WITH lang AS (
  INSERT INTO languages (code, name, flag_emoji) VALUES
    ('en', 'Inglês', '🇺🇸'),
    ('es', 'Espanhol', '🇪🇸'),
    ('fr', 'Francês', '🇫🇷'),
    ('de', 'Alemão', '🇩🇪'),
    ('ja', 'Japonês', '🇯🇵')
  RETURNING id, code
),
en AS (SELECT id FROM lang WHERE code = 'en'),
units AS (
  INSERT INTO language_units (language_id, type, title, level, content, xp_reward, is_premium, sort_order)
  SELECT en.id, u.type, u.title, u.level, u.content, u.xp_reward, u.is_premium, u.sort_order
  FROM en
  CROSS JOIN (VALUES
    ('vocabulary', 'Saudações básicas', 'A1', 'Aprenda as saudações mais comuns em inglês do dia a dia.', 10, FALSE, 1),
    ('grammar', 'Verbo To Be', 'A1', 'O verbo "to be" (ser/estar) é um dos primeiros e mais importantes verbos do inglês.', 10, FALSE, 2),
    ('conversation', 'Conversação avançada (PRO)', 'B2', 'Pratique diálogos mais complexos do cotidiano profissional.', 20, TRUE, 3)
  ) AS u(type, title, level, content, xp_reward, is_premium, sort_order)
  RETURNING id, title
),
saud AS (SELECT id FROM units WHERE title = 'Saudações básicas')
INSERT INTO vocabulary_items (unit_id, word, translation, example_sentence)
SELECT saud.id, v.word, v.translation, v.example_sentence
FROM saud
CROSS JOIN (VALUES
  ('Hello', 'Olá', 'Hello, how are you?'),
  ('Good morning', 'Bom dia', 'Good morning! Did you sleep well?'),
  ('Thank you', 'Obrigado(a)', 'Thank you for your help.'),
  ('Goodbye', 'Tchau', 'Goodbye, see you tomorrow!')
) AS v(word, translation, example_sentence);

-- ============ GAMES HUB ============

WITH games_ins AS (
  INSERT INTO games (slug, name) VALUES
    ('free-fire', 'Free Fire'),
    ('pubg', 'PUBG'),
    ('cod-mobile', 'COD Mobile'),
    ('minecraft', 'Minecraft'),
    ('roblox', 'Roblox')
  RETURNING id, slug
),
ff AS (SELECT id FROM games_ins WHERE slug = 'free-fire')
INSERT INTO game_guides (game_id, category, title, content)
SELECT ff.id, g.category, g.title, g.content
FROM ff
CROSS JOIN (VALUES
  ('sensitivity', 'Sensibilidade para mira de precisão', 'Configuração recomendada: Geral 90, Red Dot 85, 2x Scope 60, 4x Scope 40, Sniper Scope 25, Livre 100, Giroscópio 150.'),
  ('tips', '5 dicas para melhorar sua rotação', 'Sempre olhe o mapa antes de decidir a próxima zona. Priorize altura. Evite ficar parado em área aberta. Guarde granadas de fumaça para revives. Ouça passos com fone.'),
  ('hud', 'Melhor HUD para celulares de tela pequena', 'Reduza o tamanho dos botões de movimento e aumente os de mira/tiro — melhora o tempo de reação em aparelhos com tela até 6 polegadas.')
) AS g(category, title, content);

-- ============ CONQUISTAS ============
-- Os códigos abaixo são referenciados diretamente no backend
-- (achievementService.grantIfNew) — sem essas linhas, a concessão automática
-- ao concluir a 1ª aula / 1ª unidade de idioma / streak de 7 dias não tem efeito.

INSERT INTO achievements (code, name, description, xp_reward, coins_reward) VALUES
  ('first_lesson', 'Primeira Aula', 'Concluiu sua primeira aula no MEGA PLANO!', 20, 50),
  ('first_language_unit', 'Primeiro Passo Poliglota', 'Concluiu sua primeira unidade de idioma!', 20, 50),
  ('streak_7', 'Sequência de Fogo', 'Estudou por 7 dias seguidos!', 50, 100);

-- ============ LOJA ============

INSERT INTO store_products (sku, category, name, description, currency, price_coins) VALUES
  ('tema-neon-classico', 'theme', 'Tema Neon Clássico', 'O visual roxo/vermelho padrão do MEGA PLANO, em versão para desbloquear no perfil.', 'mega_coins', 300),
  ('avatar-astronauta', 'avatar', 'Avatar Astronauta', 'Avatar exclusivo para o seu perfil.', 'mega_coins', 200),
  ('moldura-dourada', 'profile_frame', 'Moldura Dourada', 'Moldura de perfil premium.', 'mega_coins', 500);

INSERT INTO store_products (sku, category, name, description, currency, price_cents) VALUES
  ('ebook-guia-estudos', 'ebook', 'Guia de Técnicas de Estudo', 'E-book com técnicas de estudo comprovadas.', 'brl', 1490);

-- ============ CUPOM DE EXEMPLO ============

INSERT INTO coupons (code, type, value, max_redemptions) VALUES
  ('BEMVINDO10', 'percent_off', 10, NULL);

COMMIT;
