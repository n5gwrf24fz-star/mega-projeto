-- MEGA PLANO — Schema do Games Hub (Fase 4)

CREATE TABLE games (
    id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug     VARCHAR(50) UNIQUE NOT NULL,   -- 'free-fire', 'pubg', 'cod-mobile', 'minecraft', 'roblox'
    name     VARCHAR(80) NOT NULL,
    icon_url TEXT,
    active   BOOLEAN NOT NULL DEFAULT TRUE  -- permite desativar um jogo sem apagar o conteúdo já criado
);

CREATE TYPE game_guide_category AS ENUM ('sensitivity', 'hud', 'device_optimizer', 'fps_settings', 'strategy', 'tips', 'news');

CREATE TABLE game_guides (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id     UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    category    game_guide_category NOT NULL,
    title       VARCHAR(150) NOT NULL,
    content     TEXT,
    device_model VARCHAR(100),   -- relevante para sensibilidade/FPS, que variam por aparelho
    is_premium  BOOLEAN NOT NULL DEFAULT FALSE,
    published_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_game_guides_game ON game_guides(game_id, category);

-- Gerador de sensibilidade: parâmetros salvos por usuário para reaproveitar/comparar
CREATE TABLE user_sensitivity_configs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    game_id     UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    device_model VARCHAR(100),
    settings    JSONB NOT NULL,   -- valores gerados (geral, mira, ads, giroscópio etc.)
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_user_sensitivity_configs_user ON user_sensitivity_configs(user_id);
