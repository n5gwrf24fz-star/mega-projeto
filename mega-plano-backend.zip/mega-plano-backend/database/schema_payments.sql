-- MEGA PLANO — Schema do sistema de pagamentos (Fase 3)

CREATE TYPE plan_type AS ENUM ('free', 'pro', 'ultra');
CREATE TYPE subscription_status AS ENUM ('trialing', 'active', 'past_due', 'canceled', 'expired');
CREATE TYPE payment_provider AS ENUM ('stripe', 'apple_iap', 'google_iap', 'mercado_pago_pix', 'paypal');
CREATE TYPE payment_status AS ENUM ('pending', 'succeeded', 'failed', 'refunded');

-- Plano atual denormalizado no usuário: evita fazer JOIN em toda checagem de
-- acesso a recurso premium (é a query mais quente do sistema).
ALTER TABLE users ADD COLUMN plan plan_type NOT NULL DEFAULT 'free';
ALTER TABLE users ADD COLUMN plan_expires_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN mega_coins INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN stripe_customer_id VARCHAR(255) UNIQUE;

CREATE TABLE subscriptions (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                 UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan                    plan_type NOT NULL,
    status                  subscription_status NOT NULL DEFAULT 'trialing',
    provider                payment_provider NOT NULL,

    -- id da assinatura no provedor (Stripe subscription id, originalTransactionId da Apple,
    -- purchaseToken do Google) — usado para reconciliar webhooks/notificações
    provider_subscription_id VARCHAR(255) UNIQUE,

    trial_ends_at           TIMESTAMPTZ,
    current_period_start    TIMESTAMPTZ,
    current_period_end      TIMESTAMPTZ,
    cancel_at_period_end    BOOLEAN NOT NULL DEFAULT FALSE,
    canceled_at             TIMESTAMPTZ,

    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);
CREATE TRIGGER trg_subscriptions_updated_at
BEFORE UPDATE ON subscriptions FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Ledger de pagamentos (toda cobrança, sucesso ou falha, fica registrada — nunca se apaga)
CREATE TABLE payments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subscription_id     UUID REFERENCES subscriptions(id) ON DELETE SET NULL,
    provider            payment_provider NOT NULL,
    provider_payment_id VARCHAR(255) UNIQUE,
    status              payment_status NOT NULL DEFAULT 'pending',
    amount_cents        INTEGER NOT NULL,
    currency            VARCHAR(3) NOT NULL DEFAULT 'BRL',
    description         VARCHAR(255),
    coupon_code         VARCHAR(50),
    metadata            JSONB,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_payments_user_id ON payments(user_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_created_at ON payments(created_at);

-- Cupons promocionais
CREATE TYPE coupon_type AS ENUM ('percent_off', 'flat_days_pro', 'mega_coins', 'course_unlock');

CREATE TABLE coupons (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code            VARCHAR(50) UNIQUE NOT NULL,
    type            coupon_type NOT NULL,
    value           INTEGER NOT NULL,        -- % de desconto, nº de dias, qtd. de coins, etc.
    max_redemptions INTEGER,                 -- NULL = ilimitado
    times_redeemed  INTEGER NOT NULL DEFAULT 0,
    expires_at      TIMESTAMPTZ,
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    created_by       UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE coupon_redemptions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    coupon_id   UUID NOT NULL REFERENCES coupons(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    redeemed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (coupon_id, user_id) -- um cupom por usuário
);

-- Loja interna
CREATE TYPE store_currency AS ENUM ('brl', 'mega_coins');
CREATE TYPE store_category AS ENUM ('theme', 'avatar', 'icon', 'profile_frame', 'course_pack', 'language_pack', 'ai_extra', 'ebook', 'premium_content');

CREATE TABLE store_products (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku             VARCHAR(80) UNIQUE NOT NULL,
    category        store_category NOT NULL,
    name            VARCHAR(150) NOT NULL,
    description     TEXT,
    image_url       TEXT,
    currency        store_currency NOT NULL,
    price_cents     INTEGER,          -- usado quando currency = 'brl'
    price_coins     INTEGER,          -- usado quando currency = 'mega_coins'
    requires_plan   plan_type,        -- ex: alguns itens só compráveis por assinantes
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE store_purchases (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id  UUID NOT NULL REFERENCES store_products(id),
    payment_id  UUID REFERENCES payments(id),   -- preenchido se pago com dinheiro real
    coins_spent INTEGER,                        -- preenchido se pago com Mega Coins
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_store_purchases_user_id ON store_purchases(user_id);

-- Ledger de Mega Coins (toda entrada/saída fica registrada, saldo em users.mega_coins é cache)
CREATE TYPE coins_reason AS ENUM (
    'lesson_completed', 'daily_login', 'challenge_completed', 'event_reward',
    'achievement', 'coin_pack_purchase', 'store_purchase', 'coupon_redemption', 'admin_grant'
);

CREATE TABLE mega_coins_transactions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount      INTEGER NOT NULL,   -- positivo = crédito, negativo = débito
    reason      coins_reason NOT NULL,
    reference_id UUID,              -- id da compra/aula/desafio relacionado, quando houver
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_coins_tx_user_id ON mega_coins_transactions(user_id);
