-- MEGA PLANO — Schema de Idiomas (Fase 4)

CREATE TABLE languages (
    id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code     VARCHAR(10) UNIQUE NOT NULL,   -- 'en', 'es', 'fr', 'de', 'ja'
    name     VARCHAR(50) NOT NULL,
    flag_emoji VARCHAR(10)
);

CREATE TYPE language_unit_type AS ENUM ('vocabulary', 'grammar', 'listening', 'speaking', 'conversation');

CREATE TABLE language_units (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    language_id  UUID NOT NULL REFERENCES languages(id) ON DELETE CASCADE,
    type         language_unit_type NOT NULL,
    title        VARCHAR(150) NOT NULL,
    level        VARCHAR(5) NOT NULL DEFAULT 'A1',   -- CEFR: A1, A2, B1, B2, C1, C2
    content      TEXT,
    audio_url    TEXT,
    xp_reward    INTEGER NOT NULL DEFAULT 10,
    is_premium   BOOLEAN NOT NULL DEFAULT FALSE,
    sort_order   INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_language_units_language ON language_units(language_id);

CREATE TABLE vocabulary_items (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    unit_id      UUID NOT NULL REFERENCES language_units(id) ON DELETE CASCADE,
    word         VARCHAR(150) NOT NULL,
    translation  VARCHAR(150) NOT NULL,
    example_sentence TEXT,
    audio_url    TEXT,
    image_url    TEXT
);

CREATE INDEX idx_vocabulary_items_unit ON vocabulary_items(unit_id);

-- Baralhos de flashcards (podem ser gerados a partir de um unit ou criados manualmente)
CREATE TABLE flashcard_decks (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    language_id UUID NOT NULL REFERENCES languages(id) ON DELETE CASCADE,
    unit_id     UUID REFERENCES language_units(id) ON DELETE SET NULL,
    title       VARCHAR(150) NOT NULL
);

CREATE TABLE flashcards (
    id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deck_id UUID NOT NULL REFERENCES flashcard_decks(id) ON DELETE CASCADE,
    front   VARCHAR(255) NOT NULL,
    back    VARCHAR(255) NOT NULL
);

-- Repetição espaçada simplificada por usuário/flashcard (algoritmo tipo Leitner)
CREATE TABLE user_flashcard_progress (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    flashcard_id UUID NOT NULL REFERENCES flashcards(id) ON DELETE CASCADE,
    box_level    INTEGER NOT NULL DEFAULT 1,     -- 1 a 5, sobe quando acerta, desce quando erra
    next_review_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (user_id, flashcard_id)
);

CREATE INDEX idx_user_flashcard_progress_review ON user_flashcard_progress(user_id, next_review_at);

CREATE TABLE user_language_progress (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    language_id   UUID NOT NULL REFERENCES languages(id) ON DELETE CASCADE,
    current_level VARCHAR(5) NOT NULL DEFAULT 'A1',
    xp_earned     INTEGER NOT NULL DEFAULT 0,
    UNIQUE (user_id, language_id)
);

CREATE TABLE user_unit_progress (
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    unit_id      UUID NOT NULL REFERENCES language_units(id) ON DELETE CASCADE,
    completed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, unit_id)
);

CREATE TABLE language_certificates (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    language_id    UUID NOT NULL REFERENCES languages(id) ON DELETE CASCADE,
    level_achieved VARCHAR(5) NOT NULL,
    certificate_url TEXT,
    issued_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_language_certificates_user ON language_certificates(user_id);
