# MEGA PLANO — Backend (Fase 1)

"Você aprende o que quiser!"

## O que já está pronto nesta fase

- Estrutura profissional de projeto Node.js/Express (config, models, controllers, routes, middlewares)
- Conexão com PostgreSQL via pool de conexões
- Conexão com Redis (preparada para cache e blacklist de tokens)
- Schema de banco: `users`, `sessions`, `verification_tokens`, `audit_logs`
- Autenticação completa com e-mail/senha:
  - Registro (senha com bcrypt, 12 salt rounds)
  - Login com JWT (access token de vida curta + refresh token de vida longa guardado em `sessions`)
  - Refresh de token
  - Logout (revoga sessão)
  - Rota `/me` protegida
- Middleware de autorização por role (`user`, `admin`, `super_admin`)
- Rate limiting nas rotas de login/registro (proteção contra força bruta)
- Validação de entrada (express-validator)
- Headers de segurança (helmet), CORS, logs (morgan)
- Tratamento de erros centralizado

## Como rodar localmente

```bash
cp .env.example .env        # preencha com suas credenciais
npm install
psql -U postgres -d mega_plano -f database/schema.sql   # cria as tabelas
npm run dev                 # inicia com nodemon em modo desenvolvimento
```

Teste rápido:
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Teste","email":"teste@email.com","password":"senha1234"}'
```

## Decisões técnicas desta fase

- **JWT de dois estágios (access + refresh)**: access token curto (15 min) minimiza dano se vazar; refresh token fica guardado em `sessions` no banco, permitindo revogar sessões individuais (ex: "sair de todos os dispositivos") sem invalidar o segredo JWT inteiro.
- **bcrypt com 12 salt rounds**: equilíbrio entre segurança e custo de CPU, padrão de mercado.
- **Pool de conexões PostgreSQL**: evita o custo de abrir/fechar conexão a cada requisição — necessário para escalar a milhares de usuários.
- **audit_logs desde já**: rastreabilidade de ações sensíveis (login, mudança de senha, mudança de role) é mais fácil de manter se existir desde o início do que adicionar depois.
- **Tudo por variável de ambiente**: nenhuma credencial hardcoded, pronto para diferentes ambientes (dev/staging/produção).

## Fase 2 — Login social, e-mail real e 2FA

- **Verificação de e-mail real**: registro agora envia e-mail de verdade via nodemailer/SMTP com link (`GET /api/auth/verify-email?token=...`). Login é bloqueado até o e-mail ser confirmado. Rota `/resend-verification` para reenviar.
- **Redefinição de senha**: `/forgot-password` → `/reset-password`, com token de 1h de validade. Ao redefinir, todas as sessões do usuário são revogadas (obriga novo login em todos os dispositivos).
- **Login Google**: `POST /api/auth/google { idToken }` — o app Flutter usa o pacote `google_sign_in` para obter o `idToken` e manda pro backend, que valida a assinatura direto com o Google (`google-auth-library`).
- **Login Apple**: `POST /api/auth/apple { identityToken, name? }` — mesma ideia com Sign in with Apple. `name` só vem preenchido no primeiro login (limitação da própria Apple).
- Contas de e-mail/senha e contas sociais se **vinculam automaticamente** quando o e-mail bate, evitando contas duplicadas.
- **2FA (TOTP, compatível com Google Authenticator/Authy)**:
  - `POST /2fa/setup` (autenticado) → gera segredo + QR code em base64
  - `POST /2fa/enable { code }` → confirma o primeiro código e ativa de vez
  - `POST /2fa/disable { code }` → desativa (exige código válido)
  - Login com 2FA ativo passa a devolver `{ requiresTwoFactor: true, tempToken }` em vez dos tokens finais
  - `POST /2fa/login-verify { tempToken, code }` → troca pelo access/refresh token de verdade
  - `tempToken` expira em 5 minutos e só serve pra essa etapa (não dá acesso a nada sozinho)

### Decisões técnicas da Fase 2

- **Token temporário de 2FA em vez de sessão parcial no banco**: mais simples e sem estado extra — o JWT de 5 min já garante que só quem passou pela senha chega no passo do código.
- **E-mails sociais são confiados como verificados**: Google e Apple já verificam o e-mail do lado deles, então pulamos nossa própria verificação nesse caso.
- **Respostas genéricas em `/forgot-password` e `/resend-verification`**: nunca revelam se um e-mail existe na base, mitigando enumeração de contas.

## Fase 3 — Sistema de Pagamentos (Freemium + Assinatura + Loja)

### Planos
Fonte única de verdade em `src/config/plans.js` (preço, limite diário de IA, dias de teste grátis, features). Mudar preço ou limite é editar um lugar só.

- **Gratuito**: matérias básicas, ferramentas essenciais, cursos gratuitos, idiomas básicos, IA limitada (`AI_FREE_DAILY_LIMIT`, padrão 20 msgs/dia), comunidade, XP, conquistas.
- **PRO** (assinatura, com teste grátis configurável via `TRIAL_DAYS_PRO`): IA quase sem limite, todos os idiomas/cursos, download offline ilimitado, ferramentas exclusivas, certificados premium, temas exclusivos, sem anúncios, acesso antecipado.
- **ULTRA**: tudo do PRO + recursos experimentais, IA mais avançada, mais armazenamento, perfil/badge exclusivo, suporte prioritário.

`ultra` satisfaz automaticamente qualquer checagem de `pro` (`planSatisfies` em `config/plans.js`).

### Cobrança por canal
- **Web/cartão/Apple Pay/Google Pay (navegador)**: Stripe Checkout (`POST /api/subscriptions/checkout/stripe`). O Checkout hospedado da própria Stripe já expõe Apple Pay/Google Pay quando o navegador é compatível — não precisou de integração separada para esses dois nesse canal.
- **iOS nativo**: obrigatório pela política da App Store usar StoreKit — o app compra localmente e manda o JWS assinado pra `POST /api/subscriptions/verify/apple`. **Atenção**: `appleIapProvider.js` decodifica o JWS mas não valida a cadeia de certificados x5c ainda — isso está marcado como TODO explícito porque depende das credenciais reais da App Store Connect (Key ID, Issuer ID, .p8). Em produção, prefira chamar a App Store Server API da Apple para verificar a transação.
- **Android nativo**: mesma lógica com Google Play Billing — `POST /api/subscriptions/verify/google` valida o `purchaseToken` direto com a Google Play Developer API (isso sim é verificação server-to-server real, via `googleapis`).
- **PIX (Brasil)**: via Mercado Pago (Stripe não cobre PIX nativamente). Usado para compras avulsas (pacotes de Mega Coins, itens de loja) — PIX não tem cobrança recorrente nativa, então assinaturas continuam via Stripe/IAP.
- **PayPal**: não implementado nesta fase (era opcional no spec); a estrutura de `paymentProviders/` já comporta adicionar um `paypalProvider.js` seguindo o mesmo padrão dos outros.

### Webhooks (fonte da verdade)
Nunca confiamos no retorno imediato do checkout no app — o estado real da assinatura só é gravado quando o webhook do provedor confirma:
- `POST /api/payments/webhooks/stripe` (checkout concluído, renovação, falha de pagamento, cancelamento) — validado por assinatura HMAC, por isso essa única rota usa `express.raw()` em vez do `express.json()` global (ver `app.js`).
- `POST /api/payments/webhooks/apple` — App Store Server Notifications V2.
- `POST /api/payments/webhooks/google` — Real-Time Developer Notifications via Pub/Sub.
- `POST /api/payments/webhooks/mercado-pago` — confirmação de PIX.

### Mega Coins
Ledger completo em `mega_coins_transactions`; o saldo em `users.mega_coins` é só um cache atualizado atomicamente dentro de uma transação SQL (`coinsModel.applyTransaction`), com `SELECT ... FOR UPDATE` pra nunca dessincronizar sob concorrência. Compráveis via PIX (`POST /api/payments/coins/buy-pix`) ou ganháveis por aulas/login diário/desafios (outros módulos chamam `coinsController.grant(...)` internamente).

### Loja interna
`store_products` cobre todas as categorias do spec (temas, avatares, ícones, molduras, pacotes de curso/idioma, extras de IA, e-books, conteúdo premium). Compra com Mega Coins é síncrona (`POST /api/store/purchase/:productId`); compra com dinheiro real segue o mesmo padrão do PIX de coins.

### Cupons
`coupon_redemptions` com `UNIQUE(coupon_id, user_id)` + transação com `FOR UPDATE` garante que um cupom com limite de uso nunca seja resgatado além da conta, mesmo com requisições simultâneas. Tipos suportados: `percent_off`, `flat_days_pro`, `mega_coins`, `course_unlock`.

### Limite diário de IA
`src/services/aiUsageService.js` usa Redis (contador com TTL de ~1 dia, não Postgres) por ser um contador de altíssima frequência sem necessidade de persistência longa. Middleware `aiUsageLimit` incrementa antes de processar a mensagem, evitando que requisições concorrentes furem o limite.

### Painel financeiro do admin (`/api/admin/finance`, exige `admin`/`super_admin`)
- `GET /subscriptions` — lista com filtro por status/plano
- `GET /revenue` — receita total e por plano num período
- `GET /summary` — usuários e assinaturas ativas por plano
- CRUD de cupons e de produtos da loja
- `POST /coins/grant` — conceder Mega Coins manualmente (restrito a `super_admin`)

### Decisões técnicas da Fase 3
- **`plan` denormalizado em `users`**: checagem de acesso a recurso premium é a query mais quente do sistema — evita JOIN com `subscriptions` toda vez, à custa de manter os dois sincronizados nos webhooks (o que já é necessário de qualquer forma).
- **Todo pagamento vira uma linha em `payments`, nunca se deleta**: histórico financeiro e auditoria dependem disso.
- **PIX separado do fluxo de assinatura**: forçar recorrência sobre um método de pagamento sem cobrança automática nativa geraria inadimplência silenciosa; assinatura recorrente fica só com Stripe/IAP, que têm renovação automática de verdade.

## Fase 4 — Banco de conteúdo (Educação, Idiomas, Jogos, Gamificação)

### Ordem de migração
Os arquivos SQL têm dependências entre si (referenciam `users`, `uuid_generate_v4()` etc.) — rode nesta ordem:
```bash
psql -U postgres -d mega_plano -f database/schema.sql
psql -U postgres -d mega_plano -f database/schema_payments.sql
psql -U postgres -d mega_plano -f database/schema_education.sql
psql -U postgres -d mega_plano -f database/schema_languages.sql
psql -U postgres -d mega_plano -f database/schema_games.sql
psql -U postgres -d mega_plano -f database/schema_gamification.sql
```

### Educação (`/api/education`)
Hierarquia: `grade_levels` (1º ano, 2º ano...) → `subjects` (Matemática, História...) → `lessons` → `exercises`. Também há `mock_exams` (simulados que agrupam exercícios de várias aulas). Progresso fica em `user_lesson_progress` e `user_exercise_attempts` — resposta de exercício nunca expõe `correct_answer` antes de o usuário responder.

### Idiomas (`/api/languages`)
`language_units` (vocabulário/gramática/listening/speaking/conversação, com nível CEFR A1-C2) + `vocabulary_items`. Flashcards seguem um algoritmo tipo Leitner simplificado (`user_flashcard_progress.box_level` 1-5, intervalo de revisão cresce a cada acerto). Certificados ficam em `language_certificates`.

### Games Hub (`/api/games`)
Conteúdo por jogo (`games` + `game_guides`, com categorias: sensibilidade, HUD, otimização de dispositivo, FPS, estratégia, dicas, notícias). `user_sensitivity_configs` guarda o histórico de configs geradas pelo usuário — o algoritmo de geração em si roda no app, o backend só persiste o resultado.

### Gamificação (`/api/gamification`)
- **XP**: ledger em `xp_events`, mesmo padrão atômico de Mega Coins (`src/services/xpService.js`). Curva de nível: nível N exige `100×N` xp a mais que o anterior — ajustável num único lugar.
- **Streak**: calculado automaticamente a cada concessão de XP, comparando `last_activity_date` com hoje/ontem — reinicia em 1 se o usuário pulou um dia.
- **Conquistas**: `src/services/achievementService.js` concede automaticamente (com recompensa de XP/coins) quando outro módulo chama `grantIfNew(userId, code)` — ex: `first_lesson`, `streak_7`, `first_language_unit`. **As conquistas em si precisam ser semeadas na tabela `achievements`** (não vêm pré-criadas); sem isso `grantIfNew` simplesmente não encontra o código e não faz nada.
- **Favoritos**: uma tabela genérica (`favorites`) cobre aulas, ferramentas, idiomas, guias de jogos, artigos, chats de IA e produtos da loja — um `content_type` + `content_id` só, em vez de uma tabela por tipo.
- **Notificações**: `notifications` com suporte a broadcast (`broadcastToAllUsers`, usado pelo admin para "Anúncios").

### Controle de acesso premium no conteúdo
`lessons.is_premium` e `language_units.is_premium` são checados nos controllers com `planSatisfies(user.plan, 'pro')` — mesmo mecanismo do `requirePlan` middleware, aplicado manualmente aqui porque a checagem depende do conteúdo específico sendo acessado (não dá pra saber estaticamente na rota).

## Fase 5 — Mega IA, Gerador de Textos e Ferramentas

### Migração adicional
```bash
psql -U postgres -d mega_plano -f database/schema_ai_tools.sql
psql -U postgres -d mega_plano -f database/seed.sql   # dados de exemplo — opcional, mas recomendado pra não abrir o app vazio
```

O `seed.sql` cadastra: todas as séries/etapas (estrutura completa, mas conteúdo só na 5ª série — Matemática com 3 aulas e exercícios), 5 idiomas (conteúdo completo só em Inglês — 3 unidades + vocabulário), 5 jogos (guias só no Free Fire), as 3 conquistas que o backend já concede automaticamente (`first_lesson`, `first_language_unit`, `streak_7` — sem isso cadastrado, a concessão automática não tem efeito nenhum), 4 produtos de loja e 1 cupom (`BEMVINDO10`).

### Mega IA (`/api/ai`)
- Conversas persistidas (`ai_conversations` + `ai_messages`), com título auto-gerado a partir da primeira mensagem.
- `context` da conversa (`study_helper`, `homework`, `writing`, `code`, `general`) troca o system prompt — cobre os casos do spec (tutor de estudos, ajuda com lição de casa, assistente de escrita, ajuda com programação).
- Modelo usado varia por plano (`src/config/aiProvider.js`): FREE/PRO usam modelos mais rápidos/baratos, ULTRA usa um modelo mais avançado — implementa literalmente o benefício "IA mais avançada" do plano ULTRA.
- `POST /api/ai/conversations/:id/messages` (`:id` pode ser `"new"`) passa pelo middleware `aiUsageLimit` da Fase 3 — é a rota que efetivamente custa dinheiro (chama a API da Anthropic).
- **Requer `ANTHROPIC_API_KEY` configurada** — sem isso a rota responde 503 de forma controlada em vez de quebrar.
- Histórico enviado à IA é limitado às últimas 20 mensagens (`MAX_HISTORY_MESSAGES`) para não deixar o custo crescer sem limite em conversas longas.

### Gerador de Textos (`/api/text-generator`)
Cobre todos os tipos do spec — currículo, carta de apresentação, recurso/contestação, e-mail, requerimento, relatório, post de rede social, mensagem profissional, e um tipo `custom` de prompt livre. Cada tipo tem um "prompt-builder" próprio (`PROMPT_BUILDERS`) que estrutura os dados do formulário antes de mandar pra IA — evita que o resultado saia fora do formato esperado. Todo texto gerado fica salvo em `generated_texts` com o histórico de inputs, e também passa por `aiUsageLimit`.

### Ferramentas de Produtividade (`/api/tools`)
- **Notas** e **Checklists**: CRUD completo com persistência (notas fixáveis, listas com itens ordenáveis).
- **Gerador de senha**: usa `crypto.randomInt` (não `Math.random`) — segurança real, não só aparência de aleatoriedade. Sem estado, sem necessidade de login.
- **QR Code**: gera um data URL base64 pronto pra exibir/exportar no app.
- **Conversor de moeda**: taxas cacheadas no Redis por 1h (câmbio não precisa ser em tempo real aqui, e evita bater numa API externa a cada requisição).
- Calculadora, conversor de unidades, cronômetro/Pomodoro, calendário, lanterna e compactador de imagem ficam inteiramente no app Flutter (não precisam de backend — são lógica local ou APIs nativas do aparelho).

### Decisões técnicas da Fase 5
- **`aiUsageLimit` reaplicado tanto na Mega IA quanto no Gerador de Textos**: os dois consomem o mesmo orçamento diário de chamadas de IA por usuário — evita ter dois limites separados que juntos ultrapassem o custo pretendido por plano.
- **PROMPT_BUILDERS como funções puras**: trocar o texto de um prompt não exige tocar no controller nem no serviço de IA.
- **Notas/checklists sem IA**: são dados simples do usuário, não precisam de LLM — mantidos fora do limite diário de IA de propósito.

## Fase 6 — Gestão de usuários, editor de conteúdo e logs de auditoria

Fecha as lacunas que o painel admin (app React separado) tinha documentado como limitação.

### Gestão de usuários (`/api/admin/users`, `/api/admin/audit-logs`)
- `GET /users?q=&role=&banned=` — busca por nome/e-mail, filtro por role e status de banimento.
- `GET /users/:id` — detalhe completo (plano, XP, Mega Coins, 2FA ativo etc.).
- `POST /users/:id/ban` / `/unban` — bane e **revoga todas as sessões ativas** na hora (senão o usuário banido continuaria autenticado até o access token expirar sozinho).
- `POST /users/:id/role` — trocar a role de alguém, **restrito a `super_admin`** e bloqueado para autopromoção (`if (req.params.id === req.user.sub)`).
- `GET /audit-logs?action=&userId=` — consulta o `audit_logs` (existe desde a Fase 1, só não tinha rota ainda).
- Toda ação sensível (ban, unban, troca de role, concessão de Mega Coins) grava uma linha em `audit_logs` automaticamente.

### Editor de conteúdo (`/api/admin/content`)
CRUD completo para o que antes só existia via `INSERT` manual no banco:
- Educação: séries, matérias, aulas, exercícios.
- Idiomas: idiomas, unidades, itens de vocabulário.
- Games: jogos, guias (ativar/desativar jogo, publicar/editar/remover guia).
- `POST /announcements` — broadcast de notificação pra todos os usuários (usa o `NotificationModel.broadcastToAllUsers` que já existia desde a Fase 4, só faltava uma rota admin pra acionar).

### Loja — corrigindo a limitação documentada no painel admin
`GET /api/admin/finance/store/products` agora existe e lista **todos** os produtos (incluindo inativos) — a rota pública `GET /store/products` continua só mostrando produtos ativos, de propósito. O painel admin deve trocar para o endpoint admin na tela de Loja pra "Reativar" voltar a funcionar de ponta a ponta.

### Decisões técnicas
- **Escrita de conteúdo entra nos models já existentes** (`GradeLevelModel.create`, `LessonModel.update`, `GameModel.createGuide`...) em vez de um model paralelo — mantém toda lógica de uma entidade no mesmo arquivo, só separando leitura pública de escrita admin dentro dele.
- **Log de auditoria é best-effort, não transacional com a ação principal**: se o log falhar por algum motivo, a ação em si (banir, criar aula) já foi commitada — preferível a travar uma ação real por causa do log.
- **Reordenação de rotas em `app.js`**: `/api/admin/finance` e `/api/admin/content` precisam ser montados *antes* do genérico `/api/admin` (rotas de usuário), senão toda requisição passaria primeiro pelo router de usuários à toa antes de cair no router certo.

## O que falta (próximas fases)

- Atualizar o painel admin (React) pra consumir `/api/admin/users`, `/api/admin/content` e `/api/admin/finance/store/products` (hoje só fala com `/api/admin/finance`)
- Atualizar o app Flutter pra consumir `/api/admin/announcements` não se aplica (é rota admin), mas as telas de Conquistas/Favoritos/Notificações do app mobile podem se beneficiar de dados reais de anúncio
- App Store Server API real pra validação Apple (pendência já documentada na Fase 3)
